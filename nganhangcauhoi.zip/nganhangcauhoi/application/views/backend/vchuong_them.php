                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Thêm chương<a href="index.php/admin/chuong"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                            <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-6 col-sm-10 col-xs-12 col-md-offset-3">
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Tên chương</label>
                            <input class="form-control" name="tenchuong" type="text" maxlength="100" placeholder="Tên chương" value="<?php echo set_value('tenchuong', ''); ?>" required autofocus >
                        </div>
                        
                        <div class="form-group">

                            <label>Chọn học phần</label>
                            <select class="form-control" id="hocphan" name="mahp">
                            <?php
                                if(isset($dshp) && count($dshp)>0){
                                    foreach ($dshp as $key => $value) {
                                        echo "<option value='{$value['mahp']}'>{$value['tenhp']}</option>";
                                    }
                                    
                                }

                            ?>
                            </select>
                        </div>

                        <input type="submit" name="submit" class="btn btn-success" value="Thêm">
                        
                    </form>

                </div>


            </div>
