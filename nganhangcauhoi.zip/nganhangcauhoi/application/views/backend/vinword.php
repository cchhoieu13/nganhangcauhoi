<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Đề thi</title>
	<base href="http://localhost:81/nganhangcauhoi/">
    <link href="template/advance-admin/assets/css/bootstrap.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="template/advance-admin/assets/js/jquery-1.10.2.js"></script>
</head>
<body>
	<div class="container">
		<?php echo($de); ?>		
	</div>
		
</body>
</html>