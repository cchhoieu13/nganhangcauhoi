                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Thêm đề<a href="index.php/admin/de"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                            <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">

                <script>
                $(document).ready(function(){
                            var stt=2;
                    // lấy chương
                    $("#hocphan").change(function(){

                        $.get("index.php/admin/de/ajax_chuongsocauhoi/"+$("#hocphan").val(), function(data, status){
                            $("#cauhoide").html(data);
                        });
                    });

                    $("#tongcau").focusout(function(){
                        if($("#tongcau").val()<10 || $("#tongcau").val()>100){
                            alert("Số câu hỏi phải từ 10 đến 100 !");
                            $("#tongcau").focus();
                        }
                        var sum=0;
                        $(".socau").each(function(){
                            if(!isNaN(this.value) && this.value.length!=0) {
                                sum += parseInt(this.value);
                            }
                        });
                        var str= "Còn "+(parseInt($("#tongcau").val())-sum)+" câu";
                        if(sum != parseInt($("#tongcau").val())){
                            $("#submit").val(str);
                            $("#submit").removeClass("btn-danger");
                            $("#submit").addClass("btn-warning");
                        }else{
                            $("#submit").val("Hoàn thành");
                            $("#submit").removeClass("btn-warning");
                            $("#submit").addClass("btn-success");
                        }
                    });

                    // $("#cauhoide").on("focus",".socau",function(){
                    //     if($("#tongcau").val()<10 || $("#tongcau").val()>100){
                    //         alert("Số câu hỏi phải từ 10 đến 100 !");
                    //         $("#tongcau").focus();
                    //     }
                    // });

                    $("#cauhoide").on("change",".socau",function(){
                        if($("#tongcau").val()<10){
                            alert("Số câu hỏi phải từ 10 đến 100 !");
                            $("#tongcau").focus();
                        }
                        var sum=0;
                        $(".socau").each(function(){
                            if(!isNaN(this.value) && this.value.length!=0) {
                                sum += parseInt(this.value);
                            }
                        });
                        var str= "Còn "+(parseInt($("#tongcau").val())-sum)+" câu";
                        if(sum != parseInt($("#tongcau").val())){
                            $("#submit").val(str);
                            $("#submit").removeClass("btn-success");
                            $("#submit").addClass("btn-warning");
                        }else{
                            $("#submit").val("Hoàn thành");
                            $("#submit").removeClass("btn-warning");
                            $("#submit").addClass("btn-success");

                        }
                        
                    });

                    $("#themde").submit(function(){
                        if($("#hocphan").val()==0){
                            alert("Bạn chưa chọn học phần !");
                            $("#hocphan").focus();
                            return false;                            
                        }

                        //lấy số câu đã chọn
                        var sum=0;
                        $(".socau").each(function(){
                            if(!isNaN(this.value) && this.value.length!=0) {
                                sum += parseInt(this.value);
                            }
                        });
                        if(sum < parseInt($("#tongcau").val())){
                            alert("Số câu hỏi chưa đủ !");
                            return false;                            
                        }
                    });
                });

                </script>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <form action="" method="post" id="themde">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="form-group col-md-6">
                                <label>Tên đề</label>
                                <input class="form-control" type="text" name="tende" placeholder="Tên đề" required autofocus >
                            </div>
                            <div class="form-group col-md-6">
                                <label>Chọn học phần</label>
                                <select class="form-control" id="hocphan" name="mahp" required autofocus>
                                    <option value='0'>Chọn học phần</option>
                                <?php
                                    if(isset($dshp) && count($dshp)>0){
                                        foreach ($dshp as $key => $value) {
                                            echo "<option value='{$value['mahp']}' ";
                                            echo $de['mahp']==$value['mahp']?"selected":"";
                                            echo ">{$value['tenhp']}</option>";
                                        }
                                        
                                    }

                                ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Thời gian làm bài</label>
                                <input class="form-control" type="number" name="thoigian" min=10 max=240 placeholder="Thời gian từ 10 đến 240 phút" value="<?php echo $de['thoigian']; ?>" required autofocus>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Số câu</label>
                                <?php
                                    $desocau=0;
                                    foreach ($dsctd as $key => $value) {
                                        $desocau +=$value['socaude']+$value['socautb']+$value['socaukh'];
                                    }
                                 ?>
                                <input class="form-control" type="number" id="tongcau" min=10 max=100 value="<?php echo $desocau; ?>" placeholder="Từ 10 đến 100 câu" required autofocus>
                            </div>
                        </div>
                        

                        <div>
                            <h1 class="page-head-line2">Thành phần câu hỏi của đề</h1>
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <table class="table table-striped" id="myTable">
                                    <thead>
                                        <tr>
                                            <th  class="col-md-6">Chương</th>
                                            <th>Dễ</th>
                                            <th>Trung bình</th>
                                            <th>Khó</th>
                                        </tr>
                                    </thead>
                                    <tbody id="cauhoide">
                                    <?php
                                        foreach ($dsctd as $key => $value) {
                                            echo "";
                                        }
                                    ?>
                                    <!-- <tr>
                                        <td>Chương 1</td>
                                        <td><input class="form-control" type="number" min="0" max="10" name="cde"></td>
                                        <td><input class="form-control" type="number" min="0" max="10" name="ctb"></td>
                                        <td><input class="form-control" type="number" min="0" max="10" name="ckh"></td>
                                    </tr> -->
                                    
                                    </tbody>
                                </table>
                                <hr style="border-top: solid 1px #00CA79;">
                            <input type="submit" name="submit" class="btn btn-danger" value="Chưa nhập số câu hỏi" id="submit">
                            </div>
                        </div>


                        
                        
                    </form>

                </div>


            </div>
