                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Thêm học phần<a href="index.php/admin/hocphan"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                            <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-6 col-sm-10 col-xs-12 col-md-offset-3">
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Mã học phần</label>
                            <input class="form-control" name="mahp" type="text" minlength="7" maxlength="8" placeholder="Mã học phần" value="<?php echo set_value('mahp', ''); ?>" required autofocus>
                        </div>
                        
                        <div class="form-group">
                            <label>Tên học phần</label>
                            <input class="form-control" name="tenhp" type="text" minlength="2" maxlength="100" placeholder="Tên học phần" value="<?php echo set_value('tenhp', ''); ?>" required autofocus >
                        </div>

                        <div class="form-group">
                            <label>Số tín chỉ</label>
                            <input class="form-control" name="sotc" type="number" min=1 max=5 placeholder="Số tín chỉ" value="<?php echo set_value('sotc', ''); ?>" required autofocus >
                        </div>

                        <input type="submit" name="submit" class="btn btn-success" value="Thêm">
                        
                    </form>

                </div>


            </div>
