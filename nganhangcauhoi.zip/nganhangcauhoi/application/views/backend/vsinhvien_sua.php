                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Cập nhật<a href="index.php/admin/sinhvien"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                            <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-6 col-sm-10 col-xs-12 col-md-offset-3">
                    <form action="" method="post">
                        
                        <div class="form-group">
                            <label>Mã sinh viên</label>
                            <input class="form-control" name="masv" type="text" maxlength="12" minlength="12" placeholder="Mã sinh viên" onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?php echo $sinhvien['masv'] ?>" required autofocus >
                        </div>
                        
                        <div class="form-group">
                            <label>Họ tên</label>
                            <input class="form-control" name="hoten" type="text" maxlength="50" minlength="2" placeholder="Họ tên" value="<?php echo $sinhvien['hoten'] ?>" onkeypress='return event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode > 191 || event.charCode == 32 ' required autofocus >
                        </div>

                        <div class="form-group">
                            <label>Mật khẩu</label>
                            <input class="form-control" name="matkhau" type="password" maxlength="20" minlength="6" placeholder="Mật khẩu" value="<?php echo $sinhvien['matkhau'] ?>" required autofocus >
                        </div>

                        <div class="form-group">
                            <label>Ngày sinh</label>
                            <input class="form-control" name="ngaysinh" type="date" value="<?php echo $sinhvien['ngaysinh'] ?>" min="1900-01-01" max="2000-12-31" required autofocus >
                        </div>

                        <input type="submit" name="submit" class="btn btn-success" value="Lưu">
                        
                    </form>

                </div>


            </div>
