                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Thêm câu hỏi<a href="index.php/admin/cauhoi"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                            <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">

                <script>
                $(document).ready(function(){
                            var stt=2;
                    // lấy chương
                    $("#hocphan").change(function(){
                        $.get("index.php/admin/chuong/ajaxschuong/"+$("#hocphan").val(), function(data, status){
                            $("#chuong").html("<option value='0'>Chọn chương</option>"+data);
                        });
                    });
                    // thêm đáp án
                    $("#themda").click(function(){
                        if(stt<10){                                      
                            stt++;
                            var data="<div class='form-group form-inline' id='divda"+stt+"'><label>Đáp án "+stt+": </label><textarea class='form-control' name='da"+stt+"' cols=50 required autofocus > </textarea> <label>Đáp án đúng :</label> <input type=checkbox class='form-control' name='cda"+stt+"' ></div>";
                                $("#dapan").append(data);
                            $("#soda").attr("value", stt);       
                        }else{
                            sweetAlert("Cảnh báo", "Câu hỏi giới hạn 10 đáp án !", "error");
                        }
                    });
                    // Bớt đáp án
                    $("#botda").click(function(){
                        if(stt>2){
                            $("#divda"+stt).remove();
                            stt--;                            
                        }else{
                            sweetAlert("Cảnh báo", "Câu hỏi phải có ít nhất 2 đáp án !", "error");
                            // alert("Câu hỏi phải có ít nhất 2 đáp án");
                        }                       
                        $("#soda").attr("value", stt);
                    });
                    // check form khi submit
                    $("#themcauhoi").submit(function(){
                        if($("#hocphan").val()==0){
                            sweetAlert("Cảnh báo", "Bạn chưa chọn học phần !", "error");
                            $("#hocphan").focus();
                            return false;                            
                        }
                        if($("#chuong").val()==0){
                            sweetAlert("Cảnh báo", "Bạn chưa chọn chương !", "error");
                            $("#chuong").focus();
                            return false;                            
                        }
                        if($("#dokho").val()==0){
                            sweetAlert("Cảnh báo", "Bạn chưa chọn độ khó !", "error");
                            $("#dokho").focus();
                            return false;                            
                        }
                        if($('input:checkbox:checked').length==$('input:checkbox').length){
                            sweetAlert("Cảnh báo", "Phải có ít nhất một đáp án sai !", "error");
                            return false;      
                        }

                        if($('input:checkbox:checked').length==0){
                            sweetAlert("Cảnh báo", "Phải có ít nhất một đáp án đúng !", "error");
                            return false;      
                        }

                        
                    });
                });

                </script>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <form action="" method="post" id="themcauhoi">
                        <div class="form-group form-inline">
                            <label>Chọn học phần</label>
                            <select class="form-control" id="hocphan" style="width: 20em">
                                <option value='0'>Chọn học phần</option>
                            <?php
                                if(isset($dshp) && count($dshp)>0){
                                    foreach ($dshp as $key => $value) {
                                        echo "<option value='{$value['mahp']}'>{$value['tenhp']}</option>";
                                    }
                                    
                                }

                            ?>
                            </select>
                            <label>Chọn chương</label>
                            <select class="form-control" id="chuong" name="machuong" style="width: 20em">                                
                                <option value='0'>Chọn chương</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Nội dung</label>
                            <textarea class="form-control" name="noidung" placeholder="Nội dung câu hỏi" required autofocus ><?php echo set_value('noidung',''); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>Chọn độ khó</label>
                            <select class="form-control" name="dokho" id="dokho">
                                <option value='0'>Chọn độ khó</option>
                                <option value='1'>Dễ</option>
                                <option value='2'>Trung bình</option>
                                <option value='3'>Khó</option>
                            </select>
                        </div>

                        

                        <div>
                            <h1 class="page-head-line2">Đáp án
                                <div style="float:right;">
                                    <button type="button" class="btn btn-success" id="themda"><span class="glyphicon glyphicon-plus"></span></button>
                                    <button type="button" class="btn btn-warning" id="botda"><span class="glyphicon glyphicon-minus"></span></button>
                                </div>
                            </h1>
                            <div id="dapan">
                                <input type="number" name="soda" id="soda" value="2" hidden >
                                <!-- thêm đáp án bằng jquery vào đây -->
                                <div class='form-group form-inline' id='divda1'>
                                    <label>Đáp án 1: </label>
                                    <textarea class='form-control' name='da1' cols=50 required autofocus ></textarea> 
                                    <label>Đáp án đúng :</label>
                                    <input type=checkbox class='form-control' name='cda1' >
                                </div>
                                <div class='form-group form-inline' id='divda2'>
                                    <label>Đáp án 2: </label>
                                    <textarea class='form-control' name='da2' cols=50 required autofocus ></textarea> 
                                    <label>Đáp án đúng :</label>
                                    <input type=checkbox class='form-control' name='cda2' >
                                </div>
                            </div>
                        </div>


                        <input type="submit" name="submit" class="btn btn-success" value="Hoàn thành">
                        
                    </form>

                </div>


            </div>
