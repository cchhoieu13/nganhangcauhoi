                <script type="text/javascript">
                    $(document).ready(function(){
                        $("#themsv").keyup(function(){
                            $.post("index.php/admin/sinhvien/ajaxsvlhp",
                            {
                                val: $("#themsv").val()
                            },
                            function(data, status){
                                $("#sinhvien").html(data);
                            });
                            $("#sinhvien").show();
                            // $.get("index.php/admin/sinhvien/ajaxdatalist/"+$("#themsv").val(), function(data, status){
                            //     $("#sinhvien").html(data);
                            // });
                        });
                    });
                </script>
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Nhập sinh viên lớp học phần<a href="index.php/admin/lophocphan"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                            <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-6" style="border-right: 1px solid #eee">
                    <div class="form-inline">
                        <div class="form-group">
                        
                            <label>Tìm sinh viên: </label>
                            <input type="text" name="themsv" id="themsv" class="form-control">
                            <button type="button" class="btn btn-success">Thêm</button>

                        </div>
                    </div>

                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th>Mã sinh viên</th>
                                <th>Họ tên</th>
                                <th>Ngày sinh</th>
                                <th>Thêm</th>
                            </tr>
                        </thead>
                        <tbody id="sinhvien">
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5">
                                    <input class="btn btn-info" type="submit" id="themnhieu" name="them" value="Thêm"></td>
                                </tr>
                            
                        </tfoot>
                    </table>

                </div>
                <!-- /////////////////////////////////////////////////////////////////////////////////////////////////// -->
                <div class="col-md-6">
                    <div class="form-inline">
                        <h4><b>Danh sách sinh viên của lớp</b></h4>
                    </div>

                    <table class="table table-striped" id="myTable">
                        <thead>
                            <tr>
                                <th>Mã sinh viên</th>
                                <th>Họ tên</th>
                                <th>Ngày sinh</th>
                                <th>Xóa</th>
                            </tr>
                        </thead>
                        <tbody id="dslhp">
                        <?php
                            if(isset($dsrs) && count($dsrs)>0){
                                foreach ($dsrs as $key => $value) {
                                    echo "<tr>                                                       
                                            <td>{$value['masv']}</td>
                                            <td>{$value['hoten']}</td>
                                            <td>{$value['ngaysinh']}</td>
                                            <td>
                                                <a title='Xóa' class=xoa href='index.php/admin/lhp_sv/xoa/{$value['masv']}' style='color: red;'><span class='glyphicon glyphicon-remove'></span></a>
                                            </td>
                                        </tr>";
                                }
                                
                            }
                        ?>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            
                        </tfoot>
                    </table>

                </div>
                
            </div>
