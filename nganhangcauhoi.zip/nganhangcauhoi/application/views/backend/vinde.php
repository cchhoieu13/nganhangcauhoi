<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Đề thi</title>
	<base href="http://localhost:81/nganhangcauhoi/">
    <link href="template/advance-admin/assets/css/bootstrap.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="template/advance-admin/assets/js/jquery-1.10.2.js"></script>
    <script type="text/javascript">
    	$(document).ready(function(){
            $(".scroll-top-wrapper").click(function(){
            	$.post("index.php/admin/de/inword",
			    {
			        htmlin: "</html>"+$("html").html()+"</html>"
			    },
			    function(data, status){
			        alert("Status: " + status);
			    });
                // $(".scroll-top-wrapper").remove();
                // $.get("index.php/admin/chuong/ajaxschuong/"+$("#hocphan").val(), function(data, status){});
            });
        });
    </script>
    <style type="text/css">
    	.scroll-top-wrapper {
		    position: fixed;
			text-align: center;
		    background-color: #999;
			color: #eeeeee;
			width: 100px;
			height: 100px;
			line-height: 48px;
			right: 30px;
			bottom: 30px;
			padding-top: 2px;
			border-top-left-radius: 10px;
			border-top-right-radius: 10px;
			border-bottom-right-radius: 10px;
			border-bottom-left-radius: 10px;
			-webkit-transition: all 0.5s ease-in-out;
			-moz-transition: all 0.5s ease-in-out;
			-ms-transition: all 0.5s ease-in-out;
			-o-transition: all 0.5s ease-in-out;
			transition: all 0.5s ease-in-out;
		}
		.scroll-top-wrapper:hover {
			background-color: #333;
		}
		.scroll-top-wrapper.show {
		    visibility:visible;
		    cursor:pointer;
			opacity: 1.0;
		}
		.scroll-top-wrapper i.glyphicon {
			line-height: inherit;
		}
    </style>
</head>
<body>
<div id="inde">
	<!-- <div class="scroll-top-wrapper">
		<a style="color:white;text-decoration: none;">
			<h2>
			  <span class="scroll-top-inner">
			    <i class="glyphicon glyphicon-print"> </i>
			  </span><br>
			  In đề
			</h2>	
		</a>
	</div> -->
	<div class="container">
		<?php echo($de); ?>
		<hr>		
		<?php echo($dade); ?>	
	</div>
	
</div>
		
</body>
</html>