<?php
// Echo "URL : http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
?><!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <base href="<?php Echo "http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/"; ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo isset($title)?$title:'Ngân hàng câu hỏi'; ?></title>
    <link rel="icon" href="template/img/icon.png" type="image/x-icon">

    <!-- BOOTSTRAP STYLES-->
    <link href="template/advance-admin/assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="template/advance-admin/assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="template/advance-admin/assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="template/advance-admin/assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='template/advance-admin/assets/css/googlefonts.css' rel='stylesheet' type='text/css' />


<script src="template/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="template/dist/sweetalert.css">
<!-- <link rel="stylesheet" type="text/css" href="template/dist/twitter.css"> -->


    <!-- JQUERY SCRIPTS -->
    <script src="template/advance-admin/assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="template/advance-admin/assets/js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="template/advance-admin/assets/js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="template/advance-admin/assets/js/custom.js"></script>
    <script src="template/advance-admin/assets/js/jquery.min.js"></script>
    <!-- MOMENT SCRIPTS -->
    <!-- Data time picker -->
    <link href='template/css/bootstrap-datetimepicker.css' rel='stylesheet' type='text/css' />
    <script src="template/js/moment.js"></script>
    <script src="template/js/bootstrap-datepicker.js"></script>

    
<script type="text/javascript">
    $(document).ready(function(){
        $("#checkAll").click(function () {
            $(".check").prop('checked', $(this).prop('checked'));
        });

        $("#myTable").on("click",".xoa",function(){
            return confirm("Bạn chắc chắn muốn xóa chứ !");
        });

        $("#xoanhieu").click(function () {
            return confirm("Bạn chắc chắn muốn xóa chứ !");
        });

    });


        
</script>

</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php/admin/index">Ngân hàng câu hỏi</a>
            </div>

            <div class="header-right">

                <!-- <a href="index.php" class="btn btn-info" title="Chưa duyệt"><b>30 </b><i class="fa fa-warning fa-2x"></i></a> -->
                <!-- <a href="message-task.html" class="btn btn-primary" title="New Task"><b>40 </b><i class="fa fa-bars fa-2x"></i></a> -->
                <a href="index.php/admin/index/logout" class="btn btn-warning" title="Đăng xuất"><i class="fa fa-power-off fa-2x"></i></a>

            </div>
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        <div class="user-img-div">
                            <!-- <img src="template/advance-admin/assets/img/user.png" class="img-thumbnail" /> -->

                            <div class="inner-text">
                                <?php echo($this->session->userdata('hoten')); ?>
                            <br />
                                <small>Đăng nhập lần cuối: 2 giờ trước </small>
                            </div>
                        </div>

                    </li>


                    <li>
                        <a<?php echo isset($active) && $active=='giaovien'?" class='active-menu'":'' ?> href="index.php/admin/giaovien"><i class="fa fa-university"></i>Giáo viên</a>
                    </li>

                    <li>
                        <a<?php echo isset($active) && $active=='sinhvien'?" class='active-menu'":'' ?> href="index.php/admin/sinhvien"><i class="fa fa-graduation-cap"></i>Sinh viên</a>
                    </li>

                    <li>
                        <a<?php echo isset($active) && $active=='hocphan'?" class='active-menu'":'' ?> href="index.php/admin/hocphan"><i class="fa fa-bookmark"></i>Học phần</a>
                    </li>

                    <li>
                        <a<?php echo isset($active) && $active=='lophocphan'?" class='active-menu'":'' ?> href="index.php/admin/lophocphan"><i class="fa fa-users"></i>Lớp học phần</a>
                    </li>

                    <li>
                        <a<?php echo isset($active) && $active=='chuong'?" class='active-menu'":'' ?> href="index.php/admin/chuong"><i class="fa fa-book"></i>Chương</a>
                    </li>

                    <li>
                        <a<?php echo isset($active) && $active=='cauhoi'?" class='active-menu'":'' ?> href="index.php/admin/cauhoi"><i class="fa fa-question"></i>Câu hỏi</a>
                    </li>

                    <!-- <li>
                        <a<?php echo isset($active) && $active=='dapan'?" class='active-menu'":'' ?> href="index.php/admin/dapan"><i class="fa fa-check-square-o"></i>Đáp án</a>
                    </li> -->

                    <li>
                        <a<?php echo isset($active) && $active=='de'?" class='active-menu'":'' ?> href="index.php/admin/de"><i class="fa fa-wpforms"></i>Đề</a>
                    </li>

                   <li>
                        <a<?php echo isset($active) && $active=='lichkt'?" class='active-menu'":'' ?> href="index.php/admin/lichkt"><i class="fa fa-calendar"></i>Lịch kiểm tra</a>
                    </li>

                    <!-- <li>
                        <a class="" href="index.html"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>

                    <li>
                        <a class="" href="index.html"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>

                    <li>
                        <a class="" href="index.html"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
 -->
                    <!-- <li>
                        <a href="#"<?php echo isset($active) && strpos($active,'cm')!=false ?" class='active-menu-top'":'' ?>><i class="fa fa-sitemap "></i>Chuyên mục <span class="fa arrow"></span></a>
                         <ul class=<?php echo isset($active) && strpos($active,'cm')!=false ?"'nav nav-second-level collapse in'":'nav nav-second-level' ?>>
                            <li>
                                <a href="index.php/admin/test/chuyenmuc"<?php echo isset($active) && $active=='addcm'?" class='active-menu'":'' ?>><i class="fa fa-bicycle "></i> Thêm</a>
                            </li>
                             <li>
                                <a href="index.php/admin/test/viewcm"<?php echo isset($active) && $active=='viewcm'?" class='active-menu'":'' ?>><i class="fa fa-flask "></i> Xem</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="#"<?php echo isset($active) && strpos($active,'bv')!=false ?" class='active-menu-top'":'' ?>><i class="fa fa-sitemap "></i>Bài viết <span class="fa arrow"></span></a>
                         <ul class=<?php echo isset($active) && strpos($active,'bv')!=false ?"'nav nav-second-level collapse in'":'nav nav-second-level' ?>>
                            <li>
                                <a href="index.php/admin/test/baiviet"<?php echo isset($active) && $active=='addbv'?" class='active-menu'":'' ?>><i class="fa fa-bicycle "></i> Thêm</a>
                            </li>
                             <li>
                                <a href="index.php/admin/test/viewbv"<?php echo isset($active) && $active=='viewbv'?" class='active-menu'":'' ?>><i class="fa fa-flask "></i> Xem</a>
                            </li>
                        </ul>
                    </li> -->

                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->


        <div id="page-wrapper">
            <div id="page-inner">
                <?php if(isset($template) && !empty($template)) { $this->load->view($template,isset($data)?$data:NULL); }  ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->


    </div>
    <!-- /. WRAPPER  -->

    <div id="footer-sec">
        &copy; 2016 Huỳnh Huy Chương | Design By : <a href="http://www.binarytheme.com/" target="_blank">BinaryTheme.com</a>
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->

</body>
</html>
