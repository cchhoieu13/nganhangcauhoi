                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Chỉnh sửa thông tin<a href="index.php/admin/giaovien"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>
                        <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-6 col-sm-10 col-xs-12 col-md-offset-3">
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Chọn quyền</label>
                            <select class="form-control" name="quyen">
                                <option value="1" <?php echo $giaovien['quyen']==1?'selected':''; ?> >Giáo viên</option>
                                <option value="2" <?php echo $giaovien['quyen']==2?'selected':''; ?> >Quản trị</option>
                                <!-- <option>Four Vale</option> -->
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Mã giáo viên</label>
                            <input class="form-control" name="magv" type="text" maxlength="6" minlength="6" placeholder="Mã giáo viên" onkeypress='return event.charCode >= 48 && event.charCode <= 57' value="<?php echo $giaovien['magv'] ?>" required autofocus >
                        </div>
                        
                        <div class="form-group">
                            <label>Họ tên</label>
                            <input class="form-control" name="hoten" type="text" maxlength="50" minlength="2" placeholder="Họ tên" value="<?php echo $giaovien['hoten'] ?>" onkeypress='return event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode > 191 || event.charCode == 32 ' required autofocus >
                        </div>

                        <div class="form-group">
                            <label>Mật khẩu</label>
                            <input class="form-control" name="matkhau" type="password" maxlength="20" minlength="6" placeholder="Mật khẩu" value="<?php echo $giaovien['matkhau'] ?>" required autofocus >
                        </div>

                        <div class="form-group">
                            <label>Ngày sinh</label>
                            <input class="form-control" name="ngaysinh" type="date" min="1900-01-01" max="1995-12-31" value="<?php echo $giaovien['ngaysinh'] ?>" required autofocus >
                        </div>

                        <input type="submit" name="submit" class="btn btn-success" value="Lưu">
                        
                    </form>

                </div>


            </div>
