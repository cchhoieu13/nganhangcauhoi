                <script>
                $(document).ready(function(){
                            var stt=2;
                    // lấy chương
                    $("#hocphan").change(function(){
                        $.get("index.php/admin/lophocphan/ajaxoption/"+$("#hocphan").val(), function(data, status){
                            $("#lophocphan").html("<option value='0'>Chọn lớp học phần</option>"+data);
                        });
                        $.get("index.php/admin/de/ajaxoption/"+$("#hocphan").val(), function(data, status){
                            $("#de").html("<option value='0'>Chọn đề</option>"+data);
                        });
                    });
                   
                    // check form khi submit
                    $("#themlichkt").submit(function(){
                        if($("#hocphan").val()==0){
                            sweetAlert("Cảnh báo", "Bạn chưa chọn học phần !", "error");
                            $("#hocphan").focus();
                            return false;                            
                        }
                        if($("#lophocphan").val()==0){
                            sweetAlert("Cảnh báo", "Bạn chưa chọn lớp học phần !", "error");
                            $("#lophocphan").focus();
                            return false;                            
                        }
                        if($("#de").val()==0){
                            sweetAlert("Cảnh báo", "Bạn chưa chọn đề !", "error");
                            $("#de").focus();
                            return false;                            
                        }
                        // if($('input:checkbox:checked').length==$('input:checkbox').length){
                        //     sweetAlert("Cảnh báo", "Phải có ít nhất một đáp án sai !", "error");
                        //     return false;      
                        // }

                        // if($('input:checkbox:checked').length==0){
                        //     sweetAlert("Cảnh báo", "Phải có ít nhất một đáp án đúng !", "error");
                        //     return false;      
                        // }                        
                    });
                });

                </script>
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Thêm lịch kiểm tra<a href="index.php/admin/lichkt"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-list"></span> Danh sách</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                            <?php echo validation_errors(); ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-6 col-sm-10 col-xs-12 col-md-offset-3">
                    <form action="" method="post" id="themlichkt">

                        <div class="form-group">
                            <label>Tên kiểm tra</label>
                            <input class="form-control" name="tenkt" type="text" maxlength=50 placeholder="Tên kiểm tra" value="<?php echo set_value('tenkt', ''); ?>" required autofocus >
                        </div>
                        
                        
                        <div class="form-group">
                            <label>Chọn học phần</label>
                            <select class="form-control" id="hocphan" name="mahp">
                                <option value='0'>Chọn học phần</option>
                            <?php
                                if(isset($dshp) && count($dshp)>0){
                                    foreach ($dshp as $key => $value) {
                                        echo "<option value='{$value['mahp']}'>{$value['tenhp']}</option>";
                                    }
                                    
                                }

                            ?>
                            </select>                            
                        </div>

                        <div class="form-group">
                            <label>Chọn lớp học phần</label>
                            <select class="form-control" id="lophocphan" name="malhp">
                                <option value='0'>Chọn lớp học phần</option>
                            </select>                            
                        </div>

                        <div class="form-group">
                            <label>Chọn đề</label>
                            <select class="form-control" id="de" name="made">
                                <option value='0'>Chọn đề</option>
                            </select>                            
                        </div>

                        <div class="form-group">
                            <label>Ngày giờ thi</label>
                            <input type='text' class="form-control" name="ngaygiokt" id='datetimepicker4' required autofocus>
                            <!-- <input class="form-control" name="ngaybatdau" type="date" min="2015-01-01" max="2050-12-31" value="<?php echo set_value('ngaygiokt', ''); ?>" required autofocus > -->

                        </div>                        
                        <script type="text/javascript">
                            $(function () {
                                $('#datetimepicker4').datetimepicker({
                                    useCurrent: false, //Important! See issue #1075
                                    format: 'YYYY-MM-DD HH:mm:ss'
                                });
                                var now = moment();
                                $('#datetimepicker4').data("DateTimePicker").minDate(now);
                            });
                        </script>
                        
                        <input type="submit" name="submit" class="btn btn-success" value="Thêm">
                        
                    </form>

                </div>


            </div>
