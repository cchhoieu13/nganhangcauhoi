                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Sinh viên<a href="index.php/admin/sinhvien/them"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-plus"></span> Thêm</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-12">
                      <!--    Striped Rows Table  -->
                            <div class="table-responsive">
                            <form action="index.php/admin/sinhvien/xoanhieu" method="post">
                                <table class="table table-striped" id="myTable">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" name="cmcheckall" class=check id="checkAll" value="all"></th>
                                            <th>Mã SV</th>
                                            <th>Họ tên</th>
                                            <th>Ngày sinh</th>
                                            <th>Mật khẩu</th>
                                            <th>Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        if(isset($dsrs) && count($dsrs)>0){
                                            foreach ($dsrs as $key => $value) {
                                                echo "<tr>
                                                        <td><input type='checkbox' class=check name='cmcheck[]' value='{$value['masv']}'></td>
                                                        <td>{$value['masv']}</td>
                                                        <td>{$value['hoten']}</td>
                                                        <td>{$value['ngaysinh']}</td>
                                                        <td>{$value['matkhau']}</td>
                                                        <td>
                                                            <a href='index.php/admin/sinhvien/sua/{$value['masv']}' style='color: green;'><span class='glyphicon glyphicon-wrench'></span></a> - 
                                                            <a class=xoa href='index.php/admin/sinhvien/xoa/{$value['masv']}' style='color: red;'><span class='glyphicon glyphicon-remove'></span></a>
                                                        </td>
                                                    </tr>";
                                            }
                                            
                                        }
                                    ?>
                                    </tbody>
                                </table>
                                <div style="float: right;"><?php echo strlen($pagination)>1?$pagination:''; ?></div>
                                <input class="btn btn-danger" type="submit" id=xoanhieu name="xoa" value="Xóa">
                            </form>
                            </div>
                    <!--  End  Striped Rows Table  -->
                </div>
            </div>
