                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Lịch kiểm tra<a href="index.php/admin/lichkt/them"><button type="button" class="btn btn-success" style="float: right;"><span class="glyphicon glyphicon-plus"></span> Thêm</button></a></h1>

                        <?php
                            $mes_flashdata=$this->session->flashdata('mes_flashdata');
                            if(isset($mes_flashdata) && count($mes_flashdata)>1){
                                echo '<div class="alert alert-'.$mes_flashdata['type'].' alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            '.$mes_flashdata['message'].'
                        </div>';
                            }
                        ?>

                    </div>
                </div>

            <div class="row">
                <div class="col-md-12">
                      <!--    Striped Rows Table  -->
                            <div class="table-responsive">

                            <div class="form-inline">
                                <div class="form-group">
                                <script>
                                // lấy chương
                                $(document).ready(function(){
                                    $("#hocphan").change(function(){
                                        $.get("index.php/admin/lophocphan/ajaxoption/"+$("#hocphan").val(), function(data, status){
                                            $("#lophocphan").html("<option value='0'>Chọn lớp học phần</option>"+data);
                                        });
                                    });
                                });

                                </script>

                                    <label>Chọn học phần</label>
                                    <select class="form-control" id="hocphan" style="width: 27em">
                                        <option value='0'>Chọn học phần</option>
                                    <?php
                                        if(isset($dshp) && count($dshp)>0){
                                            foreach ($dshp as $key => $value) {
                                                echo "<option value='{$value['mahp']}'>{$value['tenhp']}</option>";
                                            }
                                            
                                        }

                                    ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                <script>
                                $(document).ready(function(){
                                    $("#lophocphan").change(function(){
                                        $.get("index.php/admin/lichkt/ajax/"+$("#lophocphan").val(), function(data, status){
                                            $("#tblichkt").html(data);
                                        });
                                    });
                                });
                                </script>
                                    <label>Chọn lớp học phần</label>
                                    <select class="form-control" id="lophocphan" style="width: 27em">
                                        <option value='0'>Chọn lớp học phần muốn xem</option>
                                    </select>
                                </div>
                            </div>
                            
                            <hr>
                            <form action="index.php/admin/lichkt/xoanhieu" method="post">
                                <table class="table table-striped" id="myTable">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" name="cmcheckall" class=check id="checkAll" value="all"></th>
                                            <th>Tên kiểm tra</th>
                                            <th>Mã đề</th>
                                            <th>Ngày giờ KT</th>
                                            <th>Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tblichkt">
                                    <?php
                                        if(isset($dsrs) && count($dsrs)>0){
                                            foreach ($dsrs as $key => $value) {
                                                echo "<tr>
                                                        <td><input type='checkbox' class=check name='cmcheck[]' value='{$value['makt']}'></td>
                                                        <td>{$value['tenkt']}</td>
                                                        <td>{$value['made']}</td>
                                                        <td>{$value['ngaygiokt']}</td>
                                                        <td>
                                                            <a href='index.php/admin/lichkt/sua/{$value['makt']}' style='color: green;'><span class='glyphicon glyphicon-wrench'></span></a> - 
                                                            <a class=xoa href='index.php/admin/lichkt/xoa/{$value['makt']}' style='color: red;'><span class='glyphicon glyphicon-remove'></span></a>
                                                        </td>
                                                    </tr>";
                                            }
                                            
                                        }
                                    ?>
                                    </tbody>
                                </table>
                                <div style="float: right;"><?php echo strlen($pagination)>1?$pagination:''; ?></div>
                                <input class="btn btn-danger" type="submit" id=xoanhieu name="xoa" value="Xóa">
                            </form>
                            </div>
                    <!--  End  Striped Rows Table  -->
                </div>
            </div>
