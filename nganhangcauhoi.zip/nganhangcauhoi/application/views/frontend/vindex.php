<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <base href="<?php Echo "http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/"; ?>">
    <title>Ngân hàng câu hỏi</title>
    <link href="template/flat-theme/css/bootstrap.min.css" rel="stylesheet">
    <link href="template/flat-theme/css/font-awesome.min.css" rel="stylesheet">
    <link href="template/flat-theme/css/prettyPhoto.css" rel="stylesheet">
    <link href="template/flat-theme/css/animate.css" rel="stylesheet">
    <link href="template/flat-theme/css/main.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="template/flat-theme/js/html5shiv.js"></script>
    <script src="template/flat-theme/js/respond.min.js"></script>
    <![endif]-->

  <script src="template/dist/sweetalert.min.js"></script>
  <link rel="stylesheet" type="text/css" href="template/dist/sweetalert.css">

    <link rel="shortcut icon" href="template/img/icon.png">

    <script src="template/flat-theme/js/jquery.js"></script>
    <script src="template/flat-theme/js/bootstrap.min.js"></script>
    <script src="template/flat-theme/js/jquery.prettyPhoto.js"></script>
    <script src="template/flat-theme/js/main.js"></script>
    <style type="text/css">
        
.loginmodal-container {
  padding: 30px;
  max-width: 350px;
  width: 100% !important;
  background-color: #F7F7F7;
  margin: 0 auto;
  border-radius: 2px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  font-family: roboto;
}

.loginmodal-container h1 {
  text-align: center;
  font-size: 1.8em;
  font-family: roboto;
}

.loginmodal-container input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  position: relative;
}

.loginmodal-container input[type=text], input[type=password] {
  height: 44px;
  font-size: 16px;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  /* border-radius: 2px; */
  padding: 0 8px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.loginmodal-container input[type=text]:hover, input[type=password]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.loginmodal {
  text-align: center;
  font-size: 14px;
  font-family: 'Arial', sans-serif;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
/* border-radius: 3px; */
/* -webkit-user-select: none;
  user-select: none; */
}

.loginmodal-submit {
  /* border: 1px solid #3079ed; */
  border: 0px;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1); 
  background-color: #4d90fe;
  padding: 17px 0px;
  font-family: roboto;
  font-size: 14px;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#4787ed)); */
}

.loginmodal-submit:hover {
  /* border: 1px solid #2f5bb7; */
  border: 0px;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  /* background-image: -webkit-gradient(linear, 0 0, 0 100%,   from(#4d90fe), to(#357ae8)); */
}

.loginmodal-container a {
  text-decoration: none;
  color: #666;
  font-weight: 400;
  text-align: center;
  display: inline-block;
  opacity: 0.6;
  transition: opacity ease 0.5s;
} 

.login-help{
  font-size: 12px;
}
/* -----------------------------------------------------------*/
.loginmodal-container1 {
  padding: 30px;
  max-width: 600px;
  width: 100% !important;
  background-color: #F7F7F7;
  margin: 0 auto;
  border-radius: 2px;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  font-family: roboto;
}

.loginmodal-container1 h1 {
  text-align: center;
  font-size: 1.8em;
  font-family: roboto;
}

.loginmodal-container1 input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  position: relative;
}

.loginmodal-container1 input[type=text], input[type=password] {
  height: 44px;
  font-size: 16px;
  width: 100%;
  margin-bottom: 10px;
  -webkit-appearance: none;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  /* border-radius: 2px; */
  padding: 0 8px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.loginmodal-container1 input[type=text]:hover, input[type=password]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
}

.loginmodal-container1 a {
  text-decoration: none;
  color: green;
  font-weight: 400;
  text-align: center;
  display: inline-block;
  opacity: 0.6;
  transition: opacity ease 0.5s;
} 

    </style>

    <script type="text/javascript">
      $(document).ready(function(){

        $("#xemlichkt").click(function(){
            $.get("index.php/home/getlichktax", function(data, status){
                $("#dslichkt").html(data);
            });
        });

        $("#xemdiemlk").click(function(){
            $.get("index.php/home/xemdiemax", function(data, status){
                $("#dsdiemkt").html(data);
            });
        });

        $("#xemlich").on("click",".vaothi",function(){
          return confirm("Bạn chắc chắn tham gia thi chứ !");
        });

      });
    </script>
</head><!--/head-->
<body>
<!-- modal đăng nhập -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
       <div class="loginmodal-container">
            <h1>Đăng nhập</h1><br>
          <form action="index.php/home/login" method="post">
            <input type="text" name="user" placeholder="Mã người dùng">
            <input type="password" name="pass" placeholder="Mật khẩu">
            <input type="submit" name="login" class="login loginmodal-submit" value="Đăng nhập">
          </form>
        </div>
    </div>
</div><!-- modal đăng nhập -->
<!-- modal xem lịch kiểm tra -->
<div class="modal fade" id="xemlich" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
    <div class="modal-dialog">
       <div class="loginmodal-container1">
            <h1>Lịch kiểm tra</h1><br>
            <table class="table table-hover" id="dslichkt">
              <tr><th>Lớp học phần</th><th>Tên kiểm tra</th><th>Thời gian</th><th>Vào kiểm tra</th></tr>
              <tr>
                <td>215tdc01</td>
                <td>Kiểm tra giữa kỳ</td>
                <td>17.06.2016</td>
                <td><a href="index.php/vaothi">Kiểm tra</a></td>
              </tr>
            </table>          
        </div>
    </div>
</div><!-- modal xem lịch kiểm tra -->
<!-- modal xem điểm -->
<div class="modal fade" id="xemdiem" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
    <div class="modal-dialog">
       <div class="loginmodal-container1">
            <h1>Xem điểm</h1><br>
            <table class="table table-hover" id="dsdiemkt">
              <tr><th>Lớp học phần</th><th>Tên kiểm tra</th><th>Thời gian</th><th>Điểm</th></tr>
              <tr>
                <td>215tdc01</td>
                <td>Kiểm tra giữa kỳ</td>
                <td>17.06.2016</td>
                <td>56</td>
              </tr>
            </table>          
        </div>
    </div>
</div><!-- modal xem điểm -->

    <header class="navbar navbar-inverse navbar-fixed-top wet-asphalt" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php Echo "http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/"; ?>"><img src="template/img/logo.png" height="40" alt="logo"></a>
            </div>
            <div class="collapse navbar-collapse">
              <ul class="nav navbar-nav navbar-right">
                    <li class="active"><a href="<?php Echo "http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/"; ?>">Trang chủ</a></li>
                    <!-- <li><a href="about-us.html">Tin tức</a></li> -->
                    <li><a href="" role='button' data-toggle='modal' data-target='#xemlich' id="xemlichkt">Lịch kiểm tra</a></li>
                    
                    <li><a href="" role='button' data-toggle='modal' data-target='#xemdiem' id="xemdiemlk">Xem điểm</a></li>
                    
                    <?php
                      $str="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/index.php/";
                      if($this->session->userdata('masv')!=NULL){
                        echo "<li class='dropdown'>
                                  <a href='#' class='dropdown-toggle' data-toggle='dropdown'>{$this->session->userdata('hoten')} <i class='icon-angle-down'></i></a>
                                  <ul class='dropdown-menu'>
                                      <li><a href='{$str}home/logout'><span class='glyphicon glyphicon-off'></span> Đăng xuất</a></li>
                                  </ul>
                              </li>";
                      }else{                        
                        echo "<li><a href='' role='button' data-toggle='modal' data-target='#myModal'>Đăng nhập</a></li>";
                      }
                     ?>
                </ul>
                
            </div>
        </div>
    </header><!--/header-->

    <?php if(isset($template) && !empty($template)) { $this->load->view($template,isset($data)?$data:NULL); }  ?>

    <section id="bottom" class="wet-asphalt">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <h4>• Mục tiêu đề tài</h4>
                    <p>Giáo viên sẽ cung cấp câu hỏi vào ngân hàng đề thi và sử dụng câu hỏi để tạo ra đề thi. Đề thi sẽ trộn thành nhiều đề và cho phép chuyển sang định dạng file word để in ấn.</p>
                    <p>Cho phép sinh viên xem câu hỏi ôn tập và thi. Ngoài ra, thực hiện thi trắc nghiệm  trực tuyến trên mạng.</p>
                </div><!--/.col-md-3-->

                <div class="col-md-4 col-sm-6">
                    <h4>• Phương pháp nghiên cứu</h4>
                    <p>Nghiên cứu cơ sở lý thuyết về bản chất và phân loại câu hỏi trắc nghiệm.</p>
                    <p>Các website “Ngân hàng câu hỏi” đã có của các trường Đại học trên Internet và các tài iệu có liên quan.</p>
                    <p>Theo hướng dẫn của giáo viên</p>

                </div>

                <div class="col-md-4 col-sm-6">
                    <h4>• Địa chỉ</h4>
                    <address>
                        <strong>DCT, Inc.</strong><br>
                        48 Cao Thắng - Hải Châu<br>
                        Đà Nẵng<br>
                        <abbr title="Phone">P:</abbr> (+84) 122-791-7576
                    </address>
                    <h4>Nhận tin từ chúng tôi</h4>
                    <form role="form">
                        <div class="input-group">
                            <input type="text" class="form-control" autocomplete="off" placeholder="Enter your email">
                            <span class="input-group-btn">
                                <button class="btn btn-danger" type="button">Go!</button>
                            </span>
                        </div>
                    </form>
                </div> <!--/.col-md-3-->
            </div>
        </div>
    </section><!--/#bottom-->

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2016 <a target="_blank" href="http://shapebootstrap.net/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Huỳnh Huy Chương</a>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->

</body>
</html>