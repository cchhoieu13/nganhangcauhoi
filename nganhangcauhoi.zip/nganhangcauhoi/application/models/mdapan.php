<?php

class Mdapan extends CI_Model {

	var $madapan   = '';
    var $noidung;
    var $macauhoi;
    var $dung;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'madapan' => $_POST['madapan'],
               'noidung' => $_POST['noidung'],
               'macauhoi' => $_POST['macauhoi'],
               'dung' => $_POST['dung']
            );

        $this->db->where('madapan', $id);
        $this->db->update('dapan', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->noidung   = $_POST['noidung'];
        $this->macauhoi   = $_POST['macauhoi'];
        $this->dung   = $_POST['dung'];

        $this->db->insert('dapan', $this);

        $idinsert=$this->db->insert_id();

        $this->load->model('Mdapan');
        $this->Mdapan->add_theodapan($idinsert);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
    // thêm đáp án theo câu hỏi
    function add_theocauhoi($macauhoi)
    {
        for ($i = 1; $i <= $_POST['soda']; $i++) {
            $this->noidung   = $_POST['da'.$i];
            $this->macauhoi   = $macauhoi;
            $this->dung   = isset($_POST['cda'.$i])?1:0;

            $this->db->insert('dapan', $this);
        }        

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Thêm thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Thêm thất bại !' );
        }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('dapan', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('dapan');
        return $query->result_array();
    }
// lấy hết bản ghi có macauhoi = id
    function get_theocauhoi($id=0)
    {
        return $this->db->select('madapan,noidung,macauhoi,dung')->from('dapan')->where('macauhoi',$id)->get()->result_array();
    }
// lấy hết bản ghi sắp xếp random có macauhoi = id
    function get_random_cauhoi($id=0)
    {
        return $this->db->query("SELECT * FROM dapan WHERE macauhoi ={$id} ORDER BY RAND()")->result_array();
    }
// xóa hết bản ghi có macauhoi = id
    function del_theocauhoi($id=0)
    {
        $this->db->where('macauhoi', $id);
        $this->db->delete('dapan');
    }
// lấy bản ghi có madapan = id
    function get($id=0)
    {
        return $this->db->select('madapan,noidung,macauhoi,dung')->from('dapan')->where('madapan',(int)$id)->get()->result_array();
    }
// lấy tất cả bản ghi có madapan nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('madapan,noidung,macauhoi,dung');
        $this->db->from('dapan');
        $this->db->where_in('madapan',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có madapan nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('madapan',$data);
        $this->db->delete('dapan'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có madapan bằng id
    function del($id=0)    {

        $this->db->where('madapan', $id);
        $this->db->delete('dapan'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>