<?php

class Mgiaovien extends CI_Model {

	var $hoten   = '';
    var $ngaysinh;
    var $magv;
    var $matkhau;
    var $quyen;

    function __construct()
    {
        parent::__construct();
    }

    function login(){
        $data = array(
            'magv' => $_POST['user'],
            'matkhau' => $_POST['pass']
            );

        $this->db->where($data);
        $query = $this->db->get('giaovien');
        return $query->row_array();
    }

    function doipass($id=NULL){
        $data = array(
               'matkhau' => $_POST['matkhau']
            );

        $this->db->where('magv', $id);
        $this->db->update('giaovien', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Thay đổi mật khẩu thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Thay đổi thất bại !' );
        }
    }
    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'hoten' => $_POST['hoten'],
               'ngaysinh' => $_POST['ngaysinh'],
               'quyen' => $_POST['quyen'],
               'matkhau' => $_POST['matkhau']
            );

        $this->db->where('magv', $id);
        $this->db->update('giaovien', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->hoten   = $_POST['hoten'];
        $this->ngaysinh   = $_POST['ngaysinh'];
        $this->magv   = $_POST['magv'];
        $this->matkhau   = $_POST['matkhau'];
        $this->quyen   = $_POST['quyen'];

        $this->db->insert('giaovien', $this);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('giaovien', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('giaovien');
        return $query->result_array();
    }
// lấy bản ghi có magv = id
    function get($id=0)
    {
        return $this->db->select('magv,hoten,ngaysinh,matkhau,quyen')->from('giaovien')->where('magv',$id)->get()->row_array();
    }
// lấy tất cả bản ghi có magv nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('magv,hoten,ngaysinh,matkhau,quyen');
        $this->db->from('giaovien');
        $this->db->where_in('magv',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có magv nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('magv',$data);
        $this->db->delete('giaovien'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có magv bằng id
    function del($id=0)    {

        $this->db->query("DELETE FROM giaovien WHERE magv='{$id}'");

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>