<?php

class Mchuong extends CI_Model {

	var $machuong   = '';
    var $tenchuong;
    var $mahp;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'tenchuong' => $_POST['tenchuong'],
               'mahp' => $_POST['mahp']
            );

        $this->db->where('machuong', $id);
        $this->db->update('chuong', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->tenchuong   = $_POST['tenchuong'];
        $this->mahp   = $_POST['mahp'];

        $this->db->insert('chuong', $this);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('chuong', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('chuong');
        return $query->result_array();
    }
// lấy bản ghi có mahp = id
    function get_chp($id=0)
    {
        return $this->db->select('machuong,tenchuong,mahp')->from('chuong')->where('mahp',$id)->get()->result_array();
    }
// lấy bản ghi có machuong = id
    function get($id=0)
    {
        return $this->db->select('machuong,tenchuong,mahp')->from('chuong')->where('machuong',(int)$id)->get()->row_array();
    }
// lấy tất cả bản ghi có machuong nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('machuong, tenchuong,mahp');
        $this->db->from('chuong');
        $this->db->where_in('machuong',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có machuong nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('machuong',$data);
        $this->db->delete('chuong'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có machuong bằng id
    function del($id=0)    {

        $this->db->where('machuong', $id);
        $this->db->delete('chuong'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>