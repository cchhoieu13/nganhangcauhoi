<?php

class Mlichkt extends CI_Model {

	var $makt   = '';
    var $tenkt;
    var $malhp;
    var $ngaygiokt;
    var $made;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'tenkt' => $_POST['tenkt'],
               'ngaygiokt' => $_POST['ngaygiokt'],
               'made' => $_POST['made'],
               'malhp' => $_POST['malhp']
            );

        $this->db->where('makt', $id);
        $this->db->update('lichkt', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->tenkt   = $_POST['tenkt'];
        $this->malhp   = $_POST['malhp'];
        $this->ngaygiokt   = $_POST['ngaygiokt'];
        $this->made   = $_POST['made'];

        $this->db->insert('lichkt', $this);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('lichkt', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('lichkt');
        return $query->result_array();
    }
// lấy bản ghi có malhp = id
    function get_chp($id=0)
    {
        return $this->db->select('*')->from('lichkt')->where('malhp',$id)->get()->result_array();
    }
// lấy bản ghi có makt = id
    function get($id=0)
    {
        return $this->db->select('makt,tenkt,malhp,made,ngaygiokt')->from('lichkt')->where('makt',(int)$id)->get()->row_array();
    }
// lấy tất cả bản ghi có makt nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('makt,tenkt,malhp,made,ngaygiokt');
        $this->db->from('lichkt');
        $this->db->where_in('makt',$data);
        return $this->db->get()->result_array();
    }


    function get_sua($id=0)
    {
        return $this->db->query("SELECT makt,lichkt.made,lichkt.malhp,tenkt,ngaygiokt,tende,tenlhp
                    FROM lichkt INNER JOIN de ON lichkt.made = de.made
                    INNER JOIN lophocphan ON lichkt.malhp = lophocphan.malhp WHERE makt = {$id}")->row_array();
    }

// Xóa tất cả bản ghi có makt nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('makt',$data);
        $this->db->delete('lichkt'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có makt bằng id
    function del($id=0)    {

        $this->db->where('makt', $id);
        $this->db->delete('lichkt'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>