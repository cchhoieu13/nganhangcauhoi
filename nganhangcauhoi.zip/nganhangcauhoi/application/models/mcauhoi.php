<?php

class Mcauhoi extends CI_Model {

	var $macauhoi   = '';
    var $noidung;
    var $machuong;
    var $dokho;
    var $magv;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'noidung' => $_POST['noidung'],
               'machuong' => $_POST['machuong'],
               'dokho' => $_POST['dokho']
            );

        $this->db->where('macauhoi', $id);
        $this->db->update('cauhoi', $data);

        $this->Mdapan->del_theocauhoi($id);
        $this->Mdapan->add_theocauhoi($id);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->noidung   = $_POST['noidung'];
        $this->machuong   = $_POST['machuong'];
        $this->dokho   = $_POST['dokho'];
        $this->magv   = $this->session->userdata('magv');

        $this->db->insert('cauhoi', $this);

        $idinsert=$this->db->insert_id();

        $this->load->model('Mdapan');
        $this->Mdapan->add_theocauhoi($idinsert);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
    // lấy tất cả câu hỏi có mã chương bằng $machuong và độ khó = $dokho
    function get_chuong_dokho($machuong=0,$dokho=0){
        $query = $this->db->query("SELECT * FROM cauhoi WHERE machuong ='{$machuong}' and dokho='{$dokho}'");
        return $query->result_array();
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('cauhoi', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('cauhoi');
        return $query->result_array();
    }
// lấy bản ghi có machuong = id
    function get_chc($id=0)
    {
        return $this->db->query("SELECT macauhoi,machuong,noidung,dokho,cauhoi.magv,hoten
                FROM cauhoi INNER JOIN giaovien ON cauhoi.magv = giaovien.magv
                WHERE machuong = {$id}")->result_array();
    }
// lấy bản ghi có machuong = id sắp xếp random
    function get_random_chuong($id=0,$dokho,$socau)
    {
        return $this->db->query("SELECT * FROM cauhoi WHERE cauhoi.machuong ={$id} AND cauhoi.dokho ={$dokho} ORDER BY RAND() LIMIT 0,{$socau}")->result_array();
    }
// lấy bản ghi có machuong = id
    function get_chuong_giaovien($machuong,$magv)
    {
        return $this->db->query("SELECT macauhoi,machuong,noidung,dokho,cauhoi.magv,hoten
                FROM cauhoi INNER JOIN giaovien ON cauhoi.magv = giaovien.magv
                WHERE giaovien.magv = {$magv} AND machuong = {$machuong}")->result_array();
    }
// lấy bản ghi có macauhoi = id
    function get($id=0)
    {
        return $this->db->select('macauhoi,noidung,machuong,dokho')->from('cauhoi')->where('macauhoi',(int)$id)->get()->row_array();
    }

// lấy bản ghi có macauhoi = id
    function get_sua($id=0)
    {
        return $this->db->query("SELECT macauhoi,cauhoi.machuong,noidung,dokho,cauhoi.magv,tenchuong FROM cauhoi INNER JOIN chuong ON cauhoi.machuong = chuong.machuong WHERE macauhoi={$id}")->row_array();
    }

// lấy tất cả bản ghi có macauhoi nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('macauhoi,noidung,machuong,dokho');
        $this->db->from('cauhoi');
        $this->db->where_in('macauhoi',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có macauhoi nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('macauhoi',$data);
        $this->db->delete('cauhoi'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có macauhoi bằng id
    function del($id=0)    {

        $this->db->where('macauhoi', $id);
        $this->db->delete('cauhoi'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>