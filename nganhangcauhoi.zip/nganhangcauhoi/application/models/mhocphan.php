<?php

class Mhocphan extends CI_Model {

	var $mahp   = '';
    var $tenhp;
    var $sotc;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'mahp' => $_POST['mahp'],
               'tenhp' => $_POST['tenhp'],
               'sotc' => $_POST['sotc']
            );

        $this->db->where('mahp', $id);
        $this->db->update('hocphan', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->mahp   = $_POST['mahp'];
        $this->tenhp   = $_POST['tenhp'];
        $this->sotc   = $_POST['sotc'];

        $this->db->insert('hocphan', $this);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('hocphan', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('hocphan');
        return $query->result_array();
    }
// lấy bản ghi có mahp = id
    function get($id=0)
    {
        return $this->db->select('mahp,tenhp,sotc')->from('hocphan')->where('mahp',(int)$id)->get()->row_array();
    }
// lấy tất cả bản ghi có mahp nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('mahp, tenhp,sotc');
        $this->db->from('hocphan');
        $this->db->where_in('mahp',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có mahp nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('mahp',$data);
        $this->db->delete('hocphan'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có mahp bằng id
    function del($id=0)    {

        $this->db->where('mahp', $id);
        $this->db->delete('hocphan'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>