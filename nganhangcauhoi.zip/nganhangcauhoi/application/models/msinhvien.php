<?php

class Msinhvien extends CI_Model {

    var $hoten   = '';
    var $ngaysinh;
    var $masv;
    var $matkhau;

    function __construct()
    {
        parent::__construct();
    }

    function sua($id=NULL){
        $data = array(
               'hoten' => $_POST['hoten'],
               'ngaysinh' => $_POST['ngaysinh'],
               'matkhau' => $_POST['matkhau']
            );

        $this->db->where('masv', $id);
        $this->db->update('sinhvien', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->hoten   = $_POST['hoten'];
        $this->ngaysinh   = $_POST['ngaysinh'];
        $this->masv   = $_POST['masv'];
        $this->matkhau   = $_POST['matkhau'];

        $this->db->insert('sinhvien', $this);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Thêm thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Thêm thất bại !' );
        }
    }
//đăng nhập
    function login(){
        $data = array(
            'masv' => $_POST['user'],
            'matkhau' => $_POST['pass']
            );

        $this->db->where($data);
        $query = $this->db->get('sinhvien');
        return $query->row_array();
    }

// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('sinhvien', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('sinhvien');
        return $query->result_array();
    }
// lấy bản ghi có masv = id
    function get($id=0)
    {
        return $this->db->select('masv,hoten,ngaysinh,matkhau')->from('sinhvien')->where('masv',$id)->get()->row_array();
    }
// lấy tất cả bản ghi có masv nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('masv, hoten');
        $this->db->from('sinhvien');
        $this->db->where_in('masv',$data);
        return $this->db->get()->result_array();
    }

// lấy tất cả bản ghi có masv nằm trong mảng data
    function get_hoten_masv($val=NULL)
    {
        return $this->db->query("SELECT masv,hoten,ngaysinh,matkhau FROM sinhvien WHERE masv LIKE '%{$val}%' OR hoten LIKE '%{$val}%'")->result_array();
    }

// Xóa tất cả bản ghi có masv nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('masv',$data);
        $this->db->delete('sinhvien'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Không có dữ liệu nào được xóa !' );
        }
    }

// xóa bản ghi có masv bằng id
    function del($id=0)    {

        $this->db->where('masv', $id);
        $this->db->delete('sinhvien'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>