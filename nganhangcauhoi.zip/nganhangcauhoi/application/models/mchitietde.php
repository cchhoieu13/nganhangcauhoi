<?php

class Mchitietde extends CI_Model {

	var $made   = '';
    var $socaude;
    var $machuong;
    var $socautb;
    var $socaukh;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'made' => $_POST['made'],
               'socau' => $_POST['socau'],
               'machuong' => $_POST['machuong'],
               'dokho' => $_POST['dokho']
            );

        $this->db->where('made', $id);
        $this->db->update('chitietde', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add($made,$machuong,$socaude=0,$socautb=0,$socaukh=0)
    {
        $this->socaude   = $socaude;
        $this->machuong   = $machuong;
        $this->socautb   = $socautb;
        $this->socaukh   = $socaukh;
        $this->made   = $made;

        $this->db->insert('chitietde', $this);

        // $flag=$this->db->affected_rows();
        // if($flag>0){
        // 	return array('type' => 'success',
        // 					'message' => 'Thêm thành công !' );
        // }else{
        // 	return array('type' => 'danger',
        // 					'message' => 'Thêm thất bại !' );
        // }
    }
    
    function add_theode($made)
    {
        $_post = $this->input->post('data');
        foreach ($_post as $k => $v) {
            $this->add($made, $k, $v[0], $v[1], $v[2]);
        }

        // $flag=$this->db->affected_rows();
        // if($flag>0){
        //     return array('type' => 'success',
        //                     'message' => 'Thêm thành công !' );
        // }else{
        //     return array('type' => 'danger',
        //                     'message' => 'Thêm thất bại !' );
        // }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('chitietde', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('chitietde');
        return $query->result_array();
    }
// lấy hết bản ghi có machuong = id
    function get_chc($id=0)
    {
        return $this->db->select('made,socau,machuong,dokho')->from('chitietde')->where('machuong',$id)->get()->result_array();
    }
// xóa hết bản ghi có machuong = id
    function del_theocauhoi($id=0)
    {
        $this->db->where('machuong', $id);
        $this->db->delete('chitietde');
    }
// lấy bản ghi có made = id
    function get($id=0)
    {
        return $this->db->select('made,socau,machuong,dokho')->from('chitietde')->where('made',(int)$id)->get()->result_array();
    }
// lấy bản ghi có made = id sắp xếp random
    function get_random_de($id=0)
    {
        return $this->db->query("SELECT * FROM chitietde WHERE made ={$id} ORDER BY RAND()")->result_array();
    }
// lấy bản ghi có made = id có thêm tên chương
    function get_hvtenchuong($id=0)
    {
        return $this->db->query("SELECT tenchuong,made,chitietde.machuong,socaude,socautb,socaukh FROM chitietde INNER JOIN chuong ON chitietde.machuong = chuong.machuong WHERE chitietde.made ={$id}")->result_array();
    }
// lấy tất cả bản ghi có made nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('made,socau,machuong,dokho');
        $this->db->from('chitietde');
        $this->db->where_in('made',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có made nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('made',$data);
        $this->db->delete('chitietde'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có made bằng id
    function del($id=0)    {

        $this->db->where('made', $id);
        $this->db->delete('chitietde'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>