<?php

class Mde extends CI_Model {

	var $made   = '';
    var $thoigian;
    var $mahp;
    var $tende;
    var $magv;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=0){
        $data = array(
               'thoigian' => $_POST['thoigian'],
               'mahp' => $_POST['mahp'],
               'tende' => $_POST['tende']
            );

        $this->db->where('made', $id);
        $this->db->update('de', $data);

        $this->load->model('Mchitietde');
        $this->Mchitietde->del($id);
        $this->Mchitietde->add_theode($id);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }

    }
    // thêm 1 bản ghi
    function add()
    {
        $this->mahp   = $_POST['mahp'];
        $this->tende   = $_POST['tende'];
        $this->thoigian   = $_POST['thoigian'];
        $this->magv   = $this->session->userdata('magv');

        $this->db->insert('de', $this);

        $idinsert=$this->db->insert_id();

        $this->load->model('Mchitietde');
        $this->Mchitietde->add_theode($idinsert);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }

    function tinhdiem($id){
        $diem= 0;
        
        // lấy từng chi tiết để sắp xếp random
        $dsctd=$this->Mchitietde->get_random_de($id);

        foreach ($dsctd as $key => $value) {
            //$str .=print_r($value);

            $dscaude=$this->Mcauhoi->get_random_chuong($value['machuong'],1,$value['socaude']);
            $diem += count($dscaude)*1;

            $dscautb=$this->Mcauhoi->get_random_chuong($value['machuong'],2,$value['socautb']);
            $diem += count($dscautb)*2;

            $dscaukh=$this->Mcauhoi->get_random_chuong($value['machuong'],3,$value['socaukh']);
            $diem += count($dscaukh)*3;

        }
        return $diem;
    }

// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('de', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('de');
        return $query->result_array();
    }
// lấy hết bản ghi có mahp = id
    function get_dec($id=0)
    {
        return $this->db->query("SELECT made,mahp,thoigian,tende,de.magv,hoten FROM de INNER JOIN giaovien ON de.magv = giaovien.magv WHERE mahp = {$id}")->result_array();
    }
// xóa hết bản ghi có mahp = id
    function del_theocauhoi($id=0)
    {
        $this->db->where('mahp', $id);
        $this->db->delete('de');
    }
// lấy bản ghi có made = id
    function get($id=0)
    {
        return $this->db->select('made,thoigian,mahp,tende')->from('de')->where('made',(int)$id)->get()->row_array();
    }
// lấy bản ghi có made = id có tenhocphan
    function get_tenchuong($id=0)
    {
        return $this->db->query("SELECT hocphan.tenhp,de.made,de.mahp,de.thoigian,de.tende,de.magv FROM hocphan
INNER JOIN de ON de.mahp = hocphan.mahp WHERE de.made = {$id}")->row_array();
    }
// lấy tất cả bản ghi có made nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('made,thoigian,mahp,tende');
        $this->db->from('de');
        $this->db->where_in('made',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có made nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('made',$data);
        $this->db->delete('de'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có made bằng id
    function del($id=0)    {

        $this->db->where('made', $id);
        $this->db->delete('de'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>