<?php

class Mlophocphan extends CI_Model {

	var $tenlhp   = '';
    var $ngaybatdau;
    var $malhp;
    var $magv;
    var $mahp;

    function __construct()
    {
        parent::__construct();
    }

    function doipass($id=NULL){
        $data = array(
               'magv' => $_POST['magv']
            );

        $this->db->where('malhp', $id);
        $this->db->update('lophocphan', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Thay đổi mật khẩu thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Thay đổi thất bại !' );
        }
    }
    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'tenlhp' => $_POST['tenlhp'],
               'ngaybatdau' => $_POST['ngaybatdau'],
               'mahp' => $_POST['mahp'],
               'magv' => $_POST['magv']
            );

        $this->db->where('malhp', $id);
        $this->db->update('lophocphan', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        $this->tenlhp   = $_POST['tenlhp'];
        $this->ngaybatdau   = $_POST['ngaybatdau'];
        echo $this->ngaybatdau;
        $this->mahp   = $_POST['mahp'];
        $this->magv   = $_POST['magv'];

        $this->db->insert('lophocphan', $this);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('lophocphan', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('lophocphan');
        return $query->result_array();
    }
// lấy bản ghi có malhp = id
    function get($id=0)
    {
        return $this->db->select('malhp,tenlhp,ngaybatdau,magv,mahp')->from('lophocphan')->where('malhp',(int)$id)->get()->row_array();
    }
// lấy bản ghi có mahp = id
    function get_theomahp($id=0)
    {
        return $this->db->select('malhp,tenlhp,ngaybatdau,magv,mahp')->from('lophocphan')->where('mahp',(int)$id)->get()->result_array();
    }
// lấy tất cả bản ghi có malhp nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('malhp, tenlhp');
        $this->db->from('lophocphan');
        $this->db->where_in('malhp',$data);
        return $this->db->get()->result_array();
    }
// Xóa tất cả bản ghi có malhp nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('malhp',$data);
        $this->db->delete('lophocphan'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có malhp bằng id
    function del($id=0)    {

        $this->db->where('malhp', $id);
        $this->db->delete('lophocphan'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>