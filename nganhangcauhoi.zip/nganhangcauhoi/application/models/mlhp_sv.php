<?php

class Mlhp_sv extends CI_Model {

    var $ghichu;
    var $malhp;
    var $masv;

    function __construct()
    {
        parent::__construct();
    }

    //cập nhật thông tin
    function sua($id=NULL){
        $data = array(
               'ghichu' => $_POST['ghichu'],
               'masv' => $_POST['masv'],
               'malhp' => $_POST['malhp']
            );

        $this->db->where('masv', $id);
        $this->db->update('lichkt', $data);

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Chỉnh sửa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' => 'Chỉnh sửa thất bại !' );
        }
    }
    // thêm 1 bản ghi
    function add()
    {
        //$this->ghichu   = $_POST['ghichu'];
        $this->malhp   = $_POST['malhp'];
        $this->masv   = $_POST['masv'];

        $this->db->insert('lichkt', $this);

        $flag=$this->db->affected_rows();
        if($flag>0){
        	return array('type' => 'success',
        					'message' => 'Thêm thành công !' );
        }else{
        	return array('type' => 'danger',
        					'message' => 'Thêm thất bại !' );
        }
    }
// lấy từ vị trí start, với số bản ghi bằng limit
    function getlimit($start,$limit)
    {
        $query = $this->db->get('lichkt', $limit, $start);
        return $query->result_array();
    }
// lấy tất cả bản ghi
    function get_all()
    {
        $query = $this->db->get('lichkt');
        return $query->result_array();
    }
// lấy bản ghi có malhp = id
    function get_dslhp($id=0)
    {
        return $this->db->query("SELECT * FROM lhp_sv INNER JOIN sinhvien ON lhp_sv.masv = sinhvien.masv WHERE malhp = {$id}")->result_array();
    }
// lấy bản ghi có masv = id
    function get($id=0)
    {
        return $this->db->select('masv,ghichu,malhp,masv,ngaygiokt')->from('lichkt')->where('masv',(int)$id)->get()->row_array();
    }
// lấy tất cả bản ghi có masv nằm trong mảng data
    function getin($data=NULL)
    {
        $this->db->select('masv,ghichu,malhp,masv,ngaygiokt');
        $this->db->from('lichkt');
        $this->db->where_in('masv',$data);
        return $this->db->get()->result_array();
    }


    function get_sua($id=0)
    {
        return $this->db->query("SELECT masv,lichkt.masv,lichkt.malhp,ghichu,ngaygiokt,tende,tenlhp
                    FROM lichkt INNER JOIN de ON lichkt.masv = de.masv
                    INNER JOIN lophocphan ON lichkt.malhp = lophocphan.malhp WHERE masv = {$id}")->row_array();
    }

// Xóa tất cả bản ghi có masv nằm trong mảng data
    function delin($data=NULL)    {

        $this->db->where_in('masv',$data);
        $this->db->delete('lichkt'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công '.$flag.' dòng' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }

// xóa bản ghi có masv bằng id
    function del($id=0)    {

        $this->db->where('masv', $id);
        $this->db->delete('lichkt'); 

        $flag=$this->db->affected_rows();
        if($flag>0){
            return array('type' => 'success',
                            'message' => 'Xóa thành công !' );
        }else{
            return array('type' => 'danger',
                            'message' =>'Xóa thất bại !' );
        }
    }
}

?>