<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '
                            </div>');
	}

	public function __destruct(){
	}

	public function index()
	{
		$data['pagination']="";
		$data['dshp']=$this->Mhocphan->get_all();

		$data['title']='Câu hỏi';
		$data['active']='cauhoi';
		$data['template']='frontend/vhome';
		$this->load->view('frontend/vindex',isset($data)?$data:NULL);
	}

	public function nopbai(){
		$baseurl="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/";
		if(!empty($_POST['dapan'])) {			
			$this->Msinhvien_kt->update_kt($_POST['idkt']);

		    foreach($_POST['dapan'] as $check) {
		    	$this->Mketqua->add($_POST['idkt'],$check);
		    }
		}
		$diem=$this->Mketqua->td_svkt($_POST['idkt']);
		$this->Msinhvien_kt->update_diem($_POST['idkt'],$diem);
		echo "<script> alert('Nộp bài thành công: Đạt {$diem} điểm');location.href = '{$baseurl}';</script>";
	}

	public function xemdiemax()
	{
		if($this->session->userdata('masv')!=NULL){
			$masv=$this->session->userdata('masv');
			$data = $this->Msinhvien_kt->get_xemdiem($masv);
			$str="<tr><th>Lớp học phần</th><th>Tên kiểm tra</th><th>Thời gian</th><th>Điểm</th></tr>";
			foreach ($data as $key => $value) {
				$str .="<tr>
		                <td>{$value['tenlhp']}</td>
		                <td>{$value['tenkt']}</td>
		                <td>{$value['ngaygiokt']}</td>
		                <td>{$value['diem']}</td>
		              </tr>";
			}
			echo $str;
		}else{
			echo '<div class="alert alert-danger alert-dismissable">
					<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					Bạn chưa đăng nhập !
				</div>';
		}
	}


	public function logout()
	{
		if($this->session->userdata('masv')!=NULL || strlen($this->session->userdata('masv'))>0){
			$array_items = array('masv' => '', 'hoten' => '', 'ngaysinh' => '', 'matkhau' => '');
			$this->session->unset_userdata($array_items);
			$str="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/index.php/";
			header("location: ".$str);
		}else{
			$str="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/index.php/";
			header("location: ".$str);
		}
	}

	public function login()
	{
		$baseurl="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/";
		$this->load->model('Mgiaovien');
		$this->load->model('Msinhvien');
		$data1['template']='frontend/vhome';
		$this->load->view('frontend/vindex',isset($data1)?$data1:NULL);

		if($this->input->post('login')){
			if(strlen($_POST['user'])==6){
				$data = $this->Mgiaovien->login();
				if(count($data)>0){
					$this->session->set_userdata($data);
					echo("<script>alert('Đăng nhập thành công');location.href = '{$baseurl}/index.php/admin/index';</script>");
				}else{
					echo("<script>alert('Mã giáo viên hoặc mật khẩu không đúng');location.href = '{$baseurl}';</script>");
				}
			}elseif(strlen($_POST['user'])==12){
				$data = $this->Msinhvien->login();
				if(count($data)>0){
					$this->session->set_userdata($data);
					echo("<script>alert('Đăng nhập thành công');location.href = '{$baseurl}';</script>");
				}else{
					echo("<script>alert('Mã sinh viên hoặc mật khẩu không đúng');location.href = '{$baseurl}';</script>");
				}
			}else{
				echo("<script>alert('Mã người dùng không đúng');location.href = '{$baseurl}';</script>");
			}
			
		}else{
			echo("<script>location.href = '{$baseurl}';</script>");
		}

	}

	public function getlichktax(){
		$href="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/";
		if($this->session->userdata('masv')!=NULL){
			$masv=$this->session->userdata('masv');
			$lich= $this->db->query("SELECT tenlhp,tenkt,ngaygiokt,makt FROM lichkt INNER JOIN lophocphan ON lichkt.malhp = lophocphan.malhp INNER JOIN lhp_sv ON lhp_sv.malhp = lophocphan.malhp WHERE lhp_sv.masv ='{$masv}' AND
lichkt.ngaygiokt > curdate()")->result_array();
			$str="<tr><th>Lớp học phần</th><th>Tên kiểm tra</th><th>Thời gian</th><th>Vào kiểm tra</th></tr>";
			foreach ($lich as $key => $value) {
				$str .="<tr>
		                <td>{$value['tenlhp']}</td>
		                <td>{$value['tenkt']}</td>
		                <td>{$value['ngaygiokt']}</td>
		                <td><a href='{$href}index.php/home/vaothi/{$value['makt']}' class='vaothi'>Kiểm tra</a></td>
		              </tr>";
			}
			echo $str;
		}else{
			echo '<div class="alert alert-danger alert-dismissable">
					<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
					Bạn chưa đăng nhập !
				</div>';
		}
	}


	public function vaothi($makt=0){

		$this->lib->check_frontLogin();

		$baseurl="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/";
		if($makt==0){
			header("location: {$baseurl}");
		}

		$flag = $this->Msinhvien_kt->add($makt,$this->session->userdata('masv'));
		if($flag['type']=="danger"){
			echo "<script> alert('Bạn không được phép tham gia kiểm tra này');location.href = '{$baseurl}';</script>";
		}


		$ttkt= $this->Mlichkt->get($makt);//thông tin kiểm tra
		$id=$ttkt['made'];
		$ttde=$this->Mde->get($id);// thông tin đề

// hiển thị đề ---------------------------------------------------------
		$str="";
		$de=$this->Mde->get_tenchuong($id);
		$str .="<div class='row'>
			<h2 align='center'>Đề: {$de['tende']}</h2>
			<div align='center' class='col-md-6 col-md-offset-3'>
				<table>
					<tr>
						<td>							
							<h4>Môn: <br>
								Thời gian:
							</h4>
						</td>
						<td>							
							<h4>{$de['tenhp']}<br>
								{$de['thoigian']} Phút
							</h4>
						</td>
					</tr>
				</table>
			</div>
		</div>";

		$str .="<div class='row'>";
		// lấy từng chi tiết để sắp xếp random
		$dsctd=$this->Mchitietde->get_random_de($id);
		$socau=0;
		$dscauhoi;

		$sttda=1;
		foreach ($dsctd as $key => $value) {
			//$str .=print_r($value);

			$dscaude=$this->Mcauhoi->get_random_chuong($value['machuong'],1,$value['socaude']);
			
			$char=65;
			foreach ($dscaude as $ke => $va) {
				$socau++;
				$str .="<div id='cau{$socau}'>";
				$str .="<p>Câu {$socau}: {$va['noidung']}</p>";

				$dsda=$this->Mdapan->get_random_cauhoi($va['macauhoi']);
				foreach ($dsda as $k => $v) {
					$da=chr($char);
					$str .="<p><label><input type='checkbox' name='dapan[]' value='{$v['madapan']}'> - {$v['noidung']}</label></p>";
					$char++;
					$sttda++;
				}
				$str .="</div>";
				$char=65;
			}

			$dscautb=$this->Mcauhoi->get_random_chuong($value['machuong'],2,$value['socautb']);
			foreach ($dscautb as $ke => $va) {
				$socau++;
				$str .="<div id='cau{$socau}'>";
				$str .="<p>Câu {$socau}: {$va['noidung']}</p>";

				$dsda=$this->Mdapan->get_random_cauhoi($va['macauhoi']);
				foreach ($dsda as $k => $v) {
					$da=chr($char);
					$str .="<p><label><input type='checkbox' name='dapan[]' value='{$v['madapan']}'> - {$v['noidung']}</label></p>";
					$char++;
					$sttda++;
				}
				$str .="</div>";
				$char=65;
			}

			$dscaukh=$this->Mcauhoi->get_random_chuong($value['machuong'],3,$value['socaukh']);
			foreach ($dscaukh as $ke => $va) {
				$socau++;
				$str .="<div id='cau{$socau}'>";
				$str .="<p>Câu {$socau}: {$va['noidung']}</p>";

				$dsda=$this->Mdapan->get_random_cauhoi($va['macauhoi']);
				foreach ($dsda as $k => $v) {
					$da=chr($char);
					$str .="<p><label><input type='checkbox' name='dapan[]' value='{$v['madapan']}'> - {$v['noidung']}</label></p>";
					$char++;
					$sttda++;
				}
				$str .="</div>";
				$char=65;
			}

		}

		$str .="</div>";
// hiển thị đề ---------------------------------------------------------/
		$data['idkt']=$flag['idinsert'];
		$data['socau']=$socau;
		$data['ttkt']=$ttkt;
		$data['ttde']=$ttde;
		$data['de']=$str;
		$this->load->view('frontend/vkiemtra.php',isset($data)?$data:NULL);

	}

	public function xd($id){
		echo $this->Mketqua->td_svkt($id);
	}

}