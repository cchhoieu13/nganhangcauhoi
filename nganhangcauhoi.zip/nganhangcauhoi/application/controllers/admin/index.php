<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Index extends CI_Controller {

	public function __construct(){
		parent::__construct();

		$this->form_validation->set_error_delimiters('<div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '
                            </div>');
	}

	public function __destruct(){
	}

	public function index()
	{
		$this->load->view('backend/vindex');
		$this->checklogin();
	}

	public function checklogin()
	{
		if($this->session->userdata('magv')==NULL || strlen($this->session->userdata('magv'))<=0){
			$str="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/";
			header("location: ".$str);
		}
	}
	public function logout()
	{
		if($this->session->userdata('magv')!=NULL || strlen($this->session->userdata('magv'))>0){
			$array_items = array('magv' => '', 'hoten' => '', 'ngaysinh' => '', 'matkhau' => '', 'quyen' => '');				
			$this->session->unset_userdata($array_items);
			$str="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/";
			header("location: ".$str);
		}else{
			$str="http://".$_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"]."/nganhangcauhoi/";
			header("location: ".$str);
		}
	}
}