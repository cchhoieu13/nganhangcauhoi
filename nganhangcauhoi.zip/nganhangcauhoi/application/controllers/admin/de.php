<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class De extends CI_Controller {

	public function index($page=0){
		
		$data['pagination']="";
		$data['dshp']=$this->Mhocphan->get_all();

		$data['title']='Đề';
		$data['active']='de';
		$data['template']='backend/vde.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);
			

	}

	public function ajaxoption($mahp=0){

		$dsrs = $this->Mde->get_dec($mahp);	
		if(isset($dsrs) && count($dsrs)>0){
            foreach ($dsrs as $key => $value) {
                echo "<option value='{$value['made']}'>{$value['made']} - {$value['tende']}</option>";
            }
            
        }
	}

	public function ajaxrowsde($mahp=0){

		$dsrs = $this->Mde->get_dec($mahp);	
		if(isset($dsrs) && count($dsrs)>0){
            foreach ($dsrs as $key => $value) {
                echo "<tr>
                        <td><input type='checkbox' class=check name='cmcheck[]' value='{$value['made']}'></td>                                                        
                        <td>{$value['tende']}</td>
                        <td>{$value['hoten']}</td>
                        <td>{$value['thoigian']} phút</td>
                        <td>
                            <a title='Sửa' href='index.php/admin/de/sua/{$value['made']}' style='color: green;'><span class='glyphicon glyphicon-wrench'></span></a> - 
                            <a title='Xóa' class=xoa href='index.php/admin/de/xoa/{$value['made']}' style='color: red;'><span class='glyphicon glyphicon-remove'></span></a> - 
                            <a title='In' href='index.php/admin/de/inword/{$value['made']}' style='color: blue;'><span class='fa fa-print'></span></a>
                        </td>
                    </tr>";
            }
            
        }else{
        	echo "<tr>
                    <td colspan=5 align=center > Không có dữ liệu ! </td>
                </tr>";
        }
	}

	public function ajax_chuongsocauhoi($mahp=0){
		$str="";
		$dschuong = $this->Mchuong->get_chp($mahp);	
		if(isset($dschuong) && count($dschuong)>0){
            foreach ($dschuong as $key => $value) {
                $socaude=count($this->Mcauhoi->get_chuong_dokho($value['machuong'],1));
                $socautb=count($this->Mcauhoi->get_chuong_dokho($value['machuong'],2));
                $socaukh=count($this->Mcauhoi->get_chuong_dokho($value['machuong'],3));
                $str .="<tr><td>{$value['tenchuong']}</td>";
                $str .="<td class='form-inline'><input class='form-control socau' type='number' value=0 min='0' max='{$socaude}' name='data[{$value['machuong']}][]' required autofocus> / {$socaude}</td>
                      <td class='form-inline'><input class='form-control socau' type='number' value=0 min='0' max='{$socautb}' name='data[{$value['machuong']}][]' required autofocus> / {$socautb}</td>
                      <td class='form-inline'><input class='form-control socau' type='number' value=0 min='0' max='{$socaukh}' name='data[{$value['machuong']}][]' required autofocus> / {$socaukh}</td>";
                $str .="</tr>";
            }            
        }
        echo($str);
	}

	public function sua($id=0){

		if($this->input->post('submit')){
			$flag = $this->Mde->sua($id);
			$this->session->set_flashdata('mes_flashdata', $flag);
			header("location: ../");
		}

		$data['de']=$this->Mde->get($id);
		$data['dsctd']=$this->Mchitietde->get_hvtenchuong($id);
		$data['dshp']=$this->Mhocphan->get_all();
		$data['title']='Đề';
		$data['active']='de';
		$data['template']='backend/vde_sua.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function them(){

		if($this->input->post('submit')){
			$this->form_validation->set_rules('tende', 'Tên Đề', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mde->add();
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../de");
			}
		}
		
		$data['pagination']="";
		$data['dshp']=$this->Mhocphan->get_all();

		$data['title']='Đề';
		$data['active']='de';
		$data['template']='backend/vde_them.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function xoa($id=0){

		$delrow = $this->Mde->get($id);
				//Kiểm tra lấy dữ liệu đưa sang view delrow
		if(!isset($delrow) || count($delrow)==0){					
			$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Đề không tồn tại !' ));
		}else{
			$flag = $this->Mde->del($delrow['made']);				
			$this->session->set_flashdata('mes_flashdata', $flag);
		}

		header("location: ../");

			
	}

	public function xoanhieu(){

		
		if($this->input->post('xoa')){
			$dt = $this->input->post('cmcheck');
			if($dt != NULL){
				$flag = $this->Mde->delin($dt);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: de");				
			}else{
				$flag= array('type' => 'danger',
        					'message' => 'Chưa có dữ liệu được chọn !' );
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: de");	
			}
		}else{
			header("location: de");	
		}
				//Kiểm tra lấy dữ liệu đưa sang view delrow
		// if(!isset($delrow) || count($delrow)==0){					
		// 	$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Chuyên mục không tồn tại !' ));
		// 	die;
		// }
			
	}

	public function inde($id=0){
		$str="";
		$strda="<p>";
		$de=$this->Mde->get_tenchuong($id);
		$str .="<div class='row'>
			<h2 align='center'>Đề: {$de['tende']}</h2>
			<div align='center' class='col-md-6 col-md-offset-3'>
				<table>
					<tr>
						<td>							
							<h4>Môn: <br>
								Thời gian:
							</h4>
						</td>
						<td>							
							<h4>{$de['tenhp']}<br>
								{$de['thoigian']} Phút
							</h4>
						</td>
					</tr>
				</table>
			</div>
		</div>";

		$str .="<div class='row'>";
		// lấy từng chi tiết để sắp xếp random
		$dsctd=$this->Mchitietde->get_random_de($id);
		$socau=0;
		$dscauhoi;
		foreach ($dsctd as $key => $value) {
			//$str .=print_r($value);

			$dscaude=$this->Mcauhoi->get_random_chuong($value['machuong'],1,$value['socaude']);
			
			$char=65;
			foreach ($dscaude as $ke => $va) {
				$socau++;
				$str .="<p>Câu {$socau}: {$va['noidung']}</p>";
				$strda .="|| Câu {$socau}:";

				$dsda=$this->Mdapan->get_random_cauhoi($va['macauhoi']);
				foreach ($dsda as $k => $v) {
					$da=chr($char);
					$str .="<p>{$da}. {$v['noidung']}</p>";

					if($v['dung']==1){
						$strda .=" ".$da;
					}

					$char++;
				}

				$strda .=" ";
				$char=65;
			}

			$dscautb=$this->Mcauhoi->get_random_chuong($value['machuong'],2,$value['socautb']);
			foreach ($dscautb as $ke => $va) {
				$socau++;
				$str .="<p>Câu {$socau}: {$va['noidung']}</p>";
				$strda .="|| Câu {$socau}:";

				$dsda=$this->Mdapan->get_random_cauhoi($va['macauhoi']);
				foreach ($dsda as $k => $v) {
					$da=chr($char);
					$str .="<p>{$da}. {$v['noidung']}</p>";

					if($v['dung']==1){
						$strda .=" ".$da;
					}
					$char++;
				}

				$strda .=" ";
				$char=65;
			}

			$dscaukh=$this->Mcauhoi->get_random_chuong($value['machuong'],3,$value['socaukh']);
			foreach ($dscaukh as $ke => $va) {
				$socau++;
				$str .="<p>Câu {$socau}: {$va['noidung']}</p>";
				$strda .="|| Câu {$socau}:";

				$dsda=$this->Mdapan->get_random_cauhoi($va['macauhoi']);
				foreach ($dsda as $k => $v) {
					$da=chr($char);
					$str .="<p>{$da}. {$v['noidung']}</p>";

					if($v['dung']==1){
						$strda .=" ".$da;
					}
					$char++;
				}

				$strda .=" ";
				$char=65;
			}

		}

		$str .="</div>";

		$data['dade']=$strda;
		$data['de']=$str;
		$this->load->view('backend/vinde.php',isset($data)?$data:NULL);
	}

	public function inword($id=0){
		header('Content-Type: text/html; charset=utf-8');
		header("Content-Type: application/vnd.msword");
		header("Expires: 0");
		header("Cache-Control: must-revaladate, post-check=0, pre-check=0");
		header("content-disposition: attachment; filename='nganhangcauhoi.doc'");
		$this->inde($id);
	}
	public function __construct(){
		parent::__construct();
		$this->lib->check_login();
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger alert-dismissable"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '
                            </div>');
	}

	public function __destruct(){
	}
}
