<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class lophocphan extends CI_Controller {

	public function index($page=0){

		//$config['use_page_numbers'] = TRUE;

		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';

		$config['first_link'] = 'Đầu';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Cuối';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';

		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';

		$config['uri_segment'] = 4;//vị trí của biến $page mặc định 3
		$config['num_links'] = 2;
		$config['base_url'] = 'http://localhost:81/nganhangcauhoi/index.php/admin/lophocphan/xem';
		$config['total_rows'] = count($this->Mlophocphan->get_all());
		$config['per_page'] = 5; 

		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';

		$this->pagination->initialize($config);

		$data['pagination']=$this->pagination->create_links();
		$data['dsrs']=$this->Mlophocphan->getlimit($page,5);
		$data['title']='Lớp học phần';
		$data['active']='lophocphan';
		$data['template']='backend/vlophocphan.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);
			

	}

	public function sua($id=0){

		$this->load->model('Mlophocphan');

		if($this->input->post('submit')){
			$this->form_validation->set_rules('tenlhp', 'Tên lớp học phần', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mlophocphan->sua($id);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../");
			}
		}
		
		$data['dsgv']=$this->Mgiaovien->get_all();		
		$data['dshp']=$this->Mhocphan->get_all();
		$data['lophocphan']=$this->Mlophocphan->get($id);
		$data['title']='Lớp học phần';
		$data['active']='lophocphan';
		$data['template']='backend/vlophocphan_sua.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function nhapsv($id=0){

		if($this->input->post('submit')){
			$this->form_validation->set_rules('tenlhp', 'Tên lớp học phần', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mlophocphan->sua($id);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../");
			}
		}

		$data['dsrs']=$this->Mlhp_sv->get_dslhp($id);
		$data['title']='Lớp học phần';
		$data['active']='lophocphan';
		$data['template']='backend/vlophocphan_nhapsv.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function them(){

		if($this->input->post('submit')){
			$this->form_validation->set_rules('tenlhp', 'Tên lớp học phần', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mlophocphan->add();
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../lophocphan");
			}
		}

		$data['dsgv']=$this->Mgiaovien->get_all();		
		$data['dshp']=$this->Mhocphan->get_all();
		$data['title']='Lớp học phần';
		$data['active']='lophocphan';
		$data['template']='backend/vlophocphan_them.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function xoa($id=0){

		$delrow = $this->Mlophocphan->get($id);
				//Kiểm tra lấy dữ liệu đưa sang view delrow
		if(!isset($delrow) || count($delrow)==0){					
			$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Chuyên mục không tồn tại !' ));
		}else{
			$flag = $this->Mlophocphan->del($delrow['malhp']);				
			$this->session->set_flashdata('mes_flashdata', $flag);
		}

		header("location: ../");		
			
	}

	public function xoanhieu(){

		
		if($this->input->post('xoa')){
			$dt = $this->input->post('cmcheck');
			if($dt != NULL){
				$flag = $this->Mlophocphan->delin($dt);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: lophocphan");				
			}else{
				$flag= array('type' => 'danger',
        					'message' => 'Chưa có dữ liệu được chọn !' );
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../");	
			}
		}else{
			header("location: ../");	
		}
				//Kiểm tra lấy dữ liệu đưa sang view delrow
		// if(!isset($delrow) || count($delrow)==0){					
		// 	$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Chuyên mục không tồn tại !' ));
		// 	die;
		// }
			
	}
	public function ajaxoption($mahp=0){

		$dsrs = $this->Mlophocphan->get_theomahp($mahp);	
		if(isset($dsrs) && count($dsrs)>0){
            foreach ($dsrs as $key => $value) {
                echo "<option value='{$value['malhp']}'>{$value['tenlhp']}</option>";
            }
            
        }
	}

	public function __construct(){
		parent::__construct();
		$this->lib->check_login();
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger alert-dismissable"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '
                            </div>');
	}

	public function __destruct(){
	}
}
