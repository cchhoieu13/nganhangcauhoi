<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dapan extends CI_Controller {

	public function index($page=0){
		$this->load->library('pagination');

		//$config['use_page_numbers'] = TRUE;

		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';

		$config['first_link'] = 'Đầu';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Cuối';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';

		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';

		$config['uri_segment'] = 4;//vị trí của biến $page mặc định 3
		$config['num_links'] = 2;
		$config['base_url'] = 'http://localhost:81/DemoCI/index.php/test/viewcm';
		$config['total_rows'] = count($this->Mgiaovien->get_all());
		$config['per_page'] = 5; 

		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';

		$this->pagination->initialize($config);

		$data['pagination']=$this->pagination->create_links();
		$data['dsrs']=$this->Mgiaovien->get_all();
		$data['title']='Giáo viên';
		$data['active']='giaovien';
		$data['template']='backend/vgiaovien.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);
			

	}

	public function them(){

		if($this->input->post('submit')){
			$this->form_validation->set_rules('tencm', 'Tên chuyên mục', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mgiaovien->add();
				$this->session->set_flashdata('mes_flashdata', $flag);
				// header("location: chuyenmuc");
			}
		}

		$data['dsrs']=$query;
		$data['title']='Giáo viên';
		$data['active']='giaovien';
		$data['template']='backend/vgiaovien_them.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function xoa($id=0){

		$delcm = $this->Mgiaovien->get($id);
				//Kiểm tra lấy dữ liệu đưa sang view delcm
		if(!isset($delcm) || count($delcm)==0){					
			$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Dữ liệu không tồn tại !' ));
			die;
		}

		if($this->input->post('submit')){
			$flag = $this->Mgiaovien->del($delcm['macm']);				
			$this->session->set_flashdata('mes_flashdata', $flag);
			header("location: ../viewcm");	
			die;				
		}
		$data['cm']=$delcm;
		$data['title']='Xóa chuyên mục';
		$data['active']='viewcm';
		$data['template']='backend/delcm.php';
		$this->load->view('backend/index.php',isset($data)?$data:NULL);		

			
	}

	public function xoanhieu(){

		
		if($this->input->post('xoa')){
			$dt = $this->input->post('cmcheck');
			if($dt != NULL){
				$flag = $this->Mgiaovien->delin($dt);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: viewcm");				
			}else{
				$flag= array('type' => 'danger',
        					'message' => 'Chưa có dữ liệu được chọn !' );
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: viewcm");	
			}
		}else{
			header("location: viewcm");	
		}
				//Kiểm tra lấy dữ liệu đưa sang view delcm
		// if(!isset($delcm) || count($delcm)==0){					
		// 	$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Chuyên mục không tồn tại !' ));
		// 	die;
		// }
			
	}

	public function viewcm($page=0){


		//$config['use_page_numbers'] = TRUE;

		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';

		$config['first_link'] = 'Đầu';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';

		$config['last_link'] = 'Cuối';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';

		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';

		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';

		$config['cur_tag_open'] = '<li class="active"><a>';
		$config['cur_tag_close'] = '</a></li>';

		$config['uri_segment'] = 3;//vị trí của biến $page mặc định 3
		$config['num_links'] = 2;
		$config['base_url'] = 'http://localhost:81/DemoCI/index.php/test/viewcm';
		$config['total_rows'] = count($this->Mgiaovien->get_all());
		$config['per_page'] = 5; 

		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';

		$this->pagination->initialize($config);

		echo count($this->Mgiaovien->get_all());

		$data['pagination']=$this->pagination->create_links();
		$data['dscm']=$this->Mgiaovien->get_on($page,5);
		$data['title']='Chuyên mục';
		$data['active']='viewcm';
		$data['template']='backend/viewcm.php';
		$this->load->view('backend/index.php',isset($data)?$data:NULL);		
	}

	public function viewbv(){
		$data['title']='Bài viết';
		$data['active']='viewbv';
		$data['template']='backend/viewbv.php';
		$this->load->view('backend/index.php',isset($data)?$data:NULL);		
	}

	public function __construct(){
		parent::__construct();
		$this->lib->check_login();
		// $this->form_validation->set_error_delimiters('<div class="alert alert-danger alert-dismissable"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  //                               <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '
  //                           </div>');
	}

	public function __destruct(){
	}
}
