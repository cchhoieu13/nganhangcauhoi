<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class lichkt extends CI_Controller {

	public function index($page=0){
		
		$data['pagination']="";
		$data['dshp']=$this->Mhocphan->get_all();
		$data['title']='Lịch kiểm tra';
		$data['active']='lichkt';
		$data['template']='backend/vlichkt.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);					

	}

	public function sua($id=0){

		$this->load->model('Mlichkt');

		if($this->input->post('submit')){
			$this->form_validation->set_rules('tenkt', 'Tên kiểm tra', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mlichkt->sua($id);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../");
			}
		}

		$data['dshp']=$this->Mhocphan->get_all();
		$data['lichkt']=$this->Mlichkt->get_sua($id);
		$data['title']='Lịch kiểm tra';
		$data['active']='lichkt';
		$data['template']='backend/vlichkt_sua.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function them(){

		$this->load->model('Mlichkt');

		if($this->input->post('submit')){
			$this->form_validation->set_rules('tenkt', 'Tên kiểm tra', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mlichkt->add();
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../lichkt");
			}
		}

		$data['dshp']=$this->Mhocphan->get_all();
		$data['title']='Lịch kiểm tra';
		$data['active']='lichkt';
		$data['template']='backend/vlichkt_them.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function xoa($id=0){

		$delrow = $this->Mlichkt->get($id);
				//Kiểm tra lấy dữ liệu đưa sang view delrow
		if(!isset($delrow) || count($delrow)==0){					
			$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Lịch kiểm tra không tồn tại !' ));
		}else{
			$flag = $this->Mlichkt->del($delrow['makt']);				
			$this->session->set_flashdata('mes_flashdata', $flag);
		}
			header("location: ../");	
	}

	public function xoanhieu(){

		
		if($this->input->post('xoa')){
			$dt = $this->input->post('cmcheck');
			if($dt != NULL){
				$flag = $this->Mlichkt->delin($dt);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: lichkt");				
			}else{
				$flag= array('type' => 'danger',
        					'message' => 'Chưa có dữ liệu được chọn !' );
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: lichkt");	
			}
		}else{
			header("location: lichkt");	
		}
				//Kiểm tra lấy dữ liệu đưa sang view delrow
		// if(!isset($delrow) || count($delrow)==0){					
		// 	$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Chuyên mục không tồn tại !' ));
		// 	die;
		// }
			
	}

	public function ajax($malhp=0){

		$dsrs = $this->Mlichkt->get_chp($malhp);	
		if(isset($dsrs) && count($dsrs)>0){
            foreach ($dsrs as $key => $value) {
                echo "<tr>
                        <td><input type='checkbox' class=check name='cmcheck[]' value='{$value['makt']}'></td>
                            <td>{$value['tenkt']}</td>
                            <td>{$value['made']}</td>
                            <td>{$value['ngaygiokt']}</td>
                        <td>
                            <a href='index.php/admin/lichkt/sua/{$value['makt']}' style='color: green;'><span class='glyphicon glyphicon-wrench'></span></a> - 
                            <a class=xoa href='index.php/admin/lichkt/xoa/{$value['makt']}' style='color: red;'><span class='glyphicon glyphicon-remove'></span></a>
                        </td>
                    </tr>";
            }
            
        }else{
        	echo "<tr>
                    <td colspan=6 align=center > Không có dữ liệu ! </td>
                </tr>";
        }
	}

	public function ajaxslichkt($malhp=0){

		$dsrs = $this->Mlichkt->get_chp($malhp);	
		if(isset($dsrs) && count($dsrs)>0){
            foreach ($dsrs as $key => $value) {
                echo "<option value='{$value['makt']}'>{$value['tenkt']}</option>";
            }
            
        }
	}
	public function __construct(){
		parent::__construct();
		$this->lib->check_login();
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger alert-dismissable"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '
                            </div>');
	}

	public function __destruct(){
	}
}
