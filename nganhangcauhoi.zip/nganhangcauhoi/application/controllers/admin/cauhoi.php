<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cauhoi extends CI_Controller {

	public function index($page=0){
		
		$data['pagination']="";
		$data['dshp']=$this->Mhocphan->get_all();

		$data['title']='Câu hỏi';
		$data['active']='cauhoi';
		$data['template']='backend/vcauhoi.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);
			

	}

	public function ajaxchuong($machuong=0){

		$dsrs = $this->Mcauhoi->get_chc($machuong);	
		if(isset($dsrs) && count($dsrs)>0){
            foreach ($dsrs as $key => $value) {
                echo "<tr>
                        <td><input type='checkbox' class=check name='cmcheck[]' value='{$value['macauhoi']}'></td>
                        <td>{$value['noidung']}</td>
                        <td>{$value['dokho']}</td>
                        <td>{$value['hoten']}</td>
                        <td>
                            <a href='index.php/admin/cauhoi/sua/{$value['macauhoi']}' style='color: green;'><span class='glyphicon glyphicon-wrench'></span></a> - 
                            <a class=xoa href='index.php/admin/cauhoi/xoa/{$value['macauhoi']}' style='color: red;'><span class='glyphicon glyphicon-remove'></span></a>
                        </td>
                    </tr>";
            }
            
        }else{
        	echo "<tr>
                    <td colspan=5 align=center > Không có dữ liệu ! </td>
                </tr>";
        }
	}

	public function sua($id=0){


		if($this->input->post('submit')){
			$flag = $this->Mcauhoi->sua($id);
			$this->session->set_flashdata('mes_flashdata', $flag);
			header("location: ../");
		}
		$data['cauhoi']=$this->Mcauhoi->get_sua($id);
		$data['dsda']=$this->Mdapan->get_theocauhoi($id);
		$data['dshp']=$this->Mhocphan->get_all();
		$data['title']='Câu hỏi';
		$data['active']='cauhoi';
		$data['template']='backend/vcauhoi_sua.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}

	public function them(){

		if($this->input->post('submit')){
			$this->form_validation->set_rules('noidung', 'Tên Câu hỏi', 'trim|required');

			if ($this->form_validation->run() == TRUE){
				$flag = $this->Mcauhoi->add();
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: ../cauhoi/them");
			}
		}
		
		$data['pagination']="";
		$data['dshp']=$this->Mhocphan->get_all();

		$data['title']='Câu hỏi';
		$data['active']='cauhoi';
		$data['template']='backend/vcauhoi_them.php';
		$this->load->view('backend/vindex.php',isset($data)?$data:NULL);	
	}
//xóa bảng ghi có id bằng $id
	public function xoa($id=0){

		
		$delrow = $this->Mcauhoi->get($id);
				//Kiểm tra lấy dữ liệu đưa sang view delrow
		if(!isset($delrow) || count($delrow)==0){					
			$this->session->set_flashdata('mes_flashdata', array('type' => 'danger','message' =>'Mã câu hỏi không tồn tại !' ));
		}else{
			$flag = $this->Mcauhoi->del($delrow['macauhoi']);				
			$this->session->set_flashdata('mes_flashdata', $flag);
		}
		header("location: ../");	
			
	}
// xóa tất cả đáp án có chọn trong ô checkbox
	public function xoanhieu(){

		
		if($this->input->post('xoa')){
			$dt = $this->input->post('cmcheck');
			if($dt != NULL){
				$flag = $this->Mcauhoi->delin($dt);
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: cauhoi");				
			}else{
				$flag= array('type' => 'danger',
        					'message' => 'Chưa có dữ liệu được chọn !' );
				$this->session->set_flashdata('mes_flashdata', $flag);
				header("location: cauhoi");	
			}
		}else{
			header("location: cauhoi");	
		}
			
	}

	public function xem($page=0){
	
	}

	public function __construct(){
		parent::__construct();
		$this->lib->check_login();
		$this->form_validation->set_error_delimiters('<div class="alert alert-danger alert-dismissable"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>', '
                            </div>');
	}

	public function __destruct(){
	}
}
